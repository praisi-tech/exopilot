-- ====================================================================
-- EXOPILOT DB SCHEMA (Supabase / PostgreSQL DDL)
-- Designed for Indonesian Spice Export SMEs
-- Supported: Row Level Security (RLS), Auto-Audit Timestamps, constraints
-- Mapping auth.users (Firebase UUID matched via auth.users id or as custom uid)
-- ====================================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- 1. PROFILES TABLE
-- Maps Firebase authenticated users into our relational database schema.
create table public.profiles (
    id uuid primary key, -- Foreign Key to Firebase UID or auth.users
    company_name varchar(255) not null,
    main_commodity varchar(100) not null default 'Nutmeg',
    phone_number varchar(50),
    legal_entity_type varchar(50) default 'CV', -- Indonesian business types e.g. CV, PT, UD
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 2. BUYER INQUIRIES TABLE
-- Stores B2B requests from global spice purchasers (nutmeg, cloves, mace, cinnamon, etc.)
create table public.buyer_inquiries (
    id uuid default uuid_generate_v4() primary key,
    user_id uuid not null references public.profiles(id) on delete cascade,
    buyer_name varchar(255) not null,
    country varchar(100) not null,
    product varchar(150) not null, -- e.g., 'Nutmeg ABCD Grade', 'Lal Pari Cloves'
    quantity varchar(100) not null, -- e.g., '15 MT (Metric Tons)'
    status varchar(50) not null default 'New',
    price_offer varchar(50) default 'Negotiable',
    notes text,
    negotiation_notes text, -- Catatan negosiasi ekspor rincian penawaran
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
    
    -- Constraint to enforce specific, clean statuses in Indonesian spice trade workflow
    constraint check_inquiry_status check (status in ('New', 'Negotiating', 'Closed'))
);

-- 3. SHIPMENT TRACKER TABLE
-- Tracks international sea cargo containers, ETDs, ETAs, and legal document stages
create table public.shipment_tracker (
    id uuid default uuid_generate_v4() primary key,
    user_id uuid not null references public.profiles(id) on delete cascade,
    container_number varchar(50) not null, -- Standard shipping code e.g., 'EMCU8902143'
    shipping_line varchar(100) not null, -- e.g., 'Evergreen', 'Maersk', 'OOCL'
    status varchar(50) not null default 'Customs',
    commodity varchar(150) not null,
    etd date not null, -- Estimated Time of Departure (Loading ports: Tg. Priok, Tg. Perak)
    eta date not null, -- Estimated Time of Arrival (Discharge ports: Hamburg, Rotterdam, Tokyo)
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
    
    -- Constraint to validate export container status logs
    constraint check_shipment_status check (status in ('Customs', 'On Vessel', 'Arrived'))
);

-- 4. SUPPLIERS TABLE
-- Tracks local cooperatives, farm clusters, and spice growers supplying product for export
create table public.suppliers (
    id uuid default uuid_generate_v4() primary key,
    user_id uuid not null references public.profiles(id) on delete cascade,
    name varchar(255) not null,         -- Nama supplier (SME partner)
    location varchar(255) not null,     -- Lokasi/Asal supplier (e.g. Banda Neira, Ambon)
    supply_capacity varchar(100) not null, -- Kapasitas supply (e.g. 50 MT / Month)
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- ====================================================================
-- AUTO UPDATED_AT TRIGGERS (PostgreSQL)
-- Keeping updated_at field accurate on mutations
-- ====================================================================
create or replace function public.handle_update_timestamp()
returns trigger as $$
begin
    new.updated_at = now();
    return new;
end;
$$ language plpgsql;

create trigger set_profiles_updated_at
    before update on public.profiles
    for each row execute function public.handle_update_timestamp();

create trigger set_buyer_inquiries_updated_at
    before update on public.buyer_inquiries
    for each row execute function public.handle_update_timestamp();

create trigger set_shipment_tracker_updated_at
    before update on public.shipment_tracker
    for each row execute function public.handle_update_timestamp();

create trigger set_suppliers_updated_at
    before update on public.suppliers
    for each row execute function public.handle_update_timestamp();

-- ====================================================================
-- ROW LEVEL SECURITY (RLS) FOR MULTI-TENANT SAFETY
-- Assures SME data isolating based on active user UUID
-- ====================================================================
alter table public.profiles enable row level security;
alter table public.buyer_inquiries enable row level security;
alter table public.shipment_tracker enable row level security;
alter table public.suppliers enable row level security;

-- Policies for Profiles
create policy "Users can view own export profile"
    on public.profiles for select
    using (auth.uid() = id);

create policy "Users can update own export profile"
    on public.profiles for update
    using (auth.uid() = id);

-- Policies for Buyer Inquiries
create policy "SME owner can manage their own inquiries"
    on public.buyer_inquiries for all
    using (auth.uid() = user_id);

-- Policies for Shipment Tracker
create policy "SME owner can track their own shipments"
    on public.shipment_tracker for all
    using (auth.uid() = user_id);

-- Policies for Suppliers
create policy "SME owner can manage their own suppliers"
    on public.suppliers for all
    using (auth.uid() = user_id);
