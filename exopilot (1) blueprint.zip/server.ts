import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

// In-memory data store for the prototype
interface Inquiry {
  id: string;
  buyerName: string;
  country: string;
  product: string;
  quantity: string;
  price: string;
  status: "New Inquiry" | "Negotiating" | "Sample Sent" | "Waiting Payment" | "Closed Deal" | "Lost" | "New" | "Closed";
  date: string;
  negotiationNotes?: string;
  source?: string; // Alibaba, LinkedIn, Facebook, Direct, Website, etc.
  lastContactDate?: string; // YYYY-MM-DD
  followUpReminderDate?: string; // YYYY-MM-DD or null
}

interface Shipment {
  id: string;
  containerNumber: string;
  shippingLine: string;
  commodity: string;
  status: "Customs" | "On Vessel" | "Arrived";
  etd: string;
  eta: string;
}

interface Supplier {
  id: string;
  name: string;        // Nama
  location: string;    // Lokasi
  supplyCapacity: string; // Kapasitas Supply (e.g., '10 MT/Month')
  createdAt: string;
}

let suppliers: Supplier[] = [
  {
    id: "sup_1",
    name: "Koperasi Tani Banda Mutiara",
    location: "Banda Neira, Maluku",
    supplyCapacity: "15 MT / Month",
    createdAt: "2026-05-10"
  },
  {
    id: "sup_2",
    name: "CV Pala Indah Maluku",
    location: "Ambon, Maluku",
    supplyCapacity: "25 MT / Month",
    createdAt: "2026-05-12"
  },
  {
    id: "sup_3",
    name: "Sangihe Clove Association",
    location: "Sangihe, Sulawesi Utara",
    supplyCapacity: "30 MT / Month",
    createdAt: "2026-05-15"
  },
  {
    id: "sup_4",
    name: "Ujung Pandang Cassia Co-Op",
    location: "Makassar, Sulawesi Selatan",
    supplyCapacity: "50 MT / Month",
    createdAt: "2026-05-19"
  }
];

let inquiries: Inquiry[] = [
  {
    id: "inq_1",
    buyerName: "Klausen Spice GmbH",
    country: "Germany",
    product: "Nutmeg (ABCD Grade)",
    quantity: "15 MT",
    price: "$8,500/MT",
    status: "Negotiating",
    source: "Alibaba",
    lastContactDate: "2026-05-21",
    followUpReminderDate: "2026-05-24", // Tomorrow! Good to trigger follow-up reminder
    date: "2026-05-18",
    negotiationNotes: "Negotiating final payment terms (CAD vs 30% advance)."
  },
  {
    id: "inq_2",
    buyerName: "Tokyo Organic Imports",
    country: "Japan",
    product: "Cloves (Lal Pari Grade)",
    quantity: "8 MT",
    price: "$9,200/MT",
    status: "Closed Deal",
    source: "LinkedIn",
    lastContactDate: "2026-05-20",
    date: "2026-05-20",
    negotiationNotes: "Contract signed! LC opened. Container booking set."
  },
  {
    id: "inq_3",
    buyerName: "Singapore Spice Trading Hub",
    country: "Singapore",
    product: "Mace (Whole High Grade)",
    quantity: "2 MT",
    price: "$14,000/MT",
    status: "New Inquiry",
    source: "Direct",
    lastContactDate: "2026-05-22",
    followUpReminderDate: "2026-05-25",
    date: "2026-05-22",
    negotiationNotes: "Requested free shipping sample. Prefers CIF terminal delivery."
  },
  {
    id: "inq_4",
    buyerName: "Sultan Spice Co.",
    country: "Turkey",
    product: "Cassia Cinnamon (Split)",
    quantity: "20 MT",
    price: "$4,200/MT",
    status: "Negotiating",
    source: "Facebook",
    lastContactDate: "2026-05-23",
    followUpReminderDate: "2026-05-26",
    date: "2026-05-23",
    negotiationNotes: "Negotiating port of loading Belawan vs Tanjung Priok."
  },
];

let shipments: Shipment[] = [
  {
    id: "ship_1",
    containerNumber: "EMCU8902143",
    shippingLine: "Evergreen",
    commodity: "Nutmeg",
    status: "On Vessel",
    etd: "2026-05-10",
    eta: "2026-06-05",
  },
  {
    id: "ship_2",
    containerNumber: "MSKU4723920",
    shippingLine: "Maersk",
    commodity: "Cloves",
    status: "Customs",
    etd: "2026-05-21",
    eta: "2026-06-18",
  },
  {
    id: "ship_3",
    containerNumber: "OOLU5612849",
    shippingLine: "OOCL",
    commodity: "Mace",
    status: "Arrived",
    etd: "2026-04-25",
    eta: "2026-05-22",
  },
];

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // 1. GET /api/dashboard - Returns summary and list of inquiries, shipments & suppliers
  app.get("/api/dashboard", (req, res) => {
    const totalInquiries = inquiries.length;
    const activeShipments = shipments.filter(s => s.status !== "Arrived").length;
    const closedDealsCount = inquiries.filter(i => i.status === "Closed").length;
    // Calculate total pipeline value (using basic parser for mock numbers)
    let pipelineValue = 0;
    inquiries.forEach(i => {
      const q = parseFloat(i.quantity) || 0;
      const p = parseFloat(i.price.replace(/[^0-9.]/g, "")) || 0;
      if (q && p) {
        pipelineValue += q * p;
      }
    });

    res.json({
      summary: {
        totalInquiries,
        activeShipments,
        closedDeals: closedDealsCount,
        pipelineValue: `$${pipelineValue.toLocaleString()}`,
        sourcingSuppliers: suppliers.length, // Linked dynamically
        monthlyIncreaseRate: "+18.2%",
      },
      inquiries,
      shipments,
      suppliers,
    });
  });

  // 2. POST /api/inquiry - Receives and validates new buyer inquiry data to save in memory
  app.post("/api/inquiry", (req, res) => {
    const { buyerName, country, product, quantity, price, status, negotiationNotes } = req.body;

    // Strict Server-side Validation
    if (!buyerName || typeof buyerName !== "string" || buyerName.trim() === "") {
      return res.status(400).json({ error: "Buyer Name is required and must be a valid string." });
    }
    if (!country || typeof country !== "string" || country.trim() === "") {
      return res.status(400).json({ error: "Country is required." });
    }
    if (!product || typeof product !== "string" || product.trim() === "") {
      return res.status(400).json({ error: "Product/Commodity is required." });
    }
    if (!quantity || typeof quantity !== "string" || quantity.trim() === "") {
      return res.status(400).json({ error: "Quantity is required." });
    }

    const priceValue = price || "$8,000/MT";
    const statusValue = status || "New";

    if (!["New", "Negotiating", "Closed"].includes(statusValue)) {
      return res.status(400).json({ error: "Invalid status value. Must be New, Negotiating, or Closed." });
    }

    const newInquiry: Inquiry = {
      id: `inq_${Date.now()}`,
      buyerName: buyerName.trim(),
      country: country.trim(),
      product: product.trim(),
      quantity: quantity.trim(),
      price: priceValue.trim(),
      status: statusValue as "New" | "Negotiating" | "Closed",
      date: new Date().toISOString().split("T")[0],
      negotiationNotes: negotiationNotes ? String(negotiationNotes).trim() : "",
    };

    inquiries.unshift(newInquiry);

    res.status(201).json({
      message: "Buyer inquiry added successfully",
      inquiry: newInquiry,
      inquiries,
    });
  });

  // 3. POST /api/generate-document - Gemini SDK dynamic quotation letter generator
  app.post("/api/generate-document", async (req, res) => {
    const { docType, buyerName, commodity, quantity, price, destinationCountry, negotiationNotes } = req.body;

    if (!buyerName || !commodity || !quantity) {
      return res.status(400).json({ error: "Missing required fields: buyerName, commodity, and quantity." });
    }

    const docTypeVal = docType || "Quotation";
    const countryVal = destinationCountry || "Netherlands";
    const priceVal = price || "negotiable";
    const notesVal = negotiationNotes ? String(negotiationNotes).trim() : "";
    const dateToday = new Date().toISOString().split('T')[0];
    const serialRef = `EX-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        // Return custom premium fallback templates based on selected document type
        let mockDocumentText = "";

        if (docTypeVal.toLowerCase().includes("invoice")) {
          mockDocumentText = `
# COMMERCIAL INVOICE
**PT REMPAH NUSANTARA ABADI**  
*Exopilot Co-Op Group, Cargo Tower B-10, Tanjung Priok, Jakarta, Indonesia*  
*Email: export@exopilot.co | Tel: +62-21-555-0193*  

---

### **DOCUMENT METRICS**
* **Invoice Number:** INV/${new Date().getFullYear()}/${Math.floor(100000 + Math.random() * 900000)}  
* **Date:** ${dateToday}  
* **Ref/Serial:** ${serialRef}  
* **Payment Terms:** 30% Advance T/T Deposit, 70% against Bill of Lading (B/L) Documents  
* **FOB Port:** Tanjung Priok, Jakarta, Indonesia  

---

### **PARTIES OF THE TRANSACTION**
**Seller / Consignor:**  
PT Rempah Nusantara Abadi  
Jakarta, Republic of Indonesia  

**Buyer / Consignee:**  
${buyerName}  
Sourcing Division, ${countryVal}  

---

### **CONSIGNMENT BREAKDOWN & COST SHEET**

| Item Description | Country of Origin | Certified Volume | Unit Price (FOB USD) | Total Carriage Value (USD) |
| :--- | :--- | :--- | :--- | :--- |
| **${commodity}** | Indonesia | ${quantity} | ${priceVal.includes("$") ? priceVal : "$" + priceVal + "/MT"} | $${(parseFloat(quantity) * (parseFloat(priceVal.replace(/[^0-9.]/g, "")) || 8000)).toLocaleString() || "120,000"} USD |

* **Total Cargo Declared:** 1x 20FT FCL Container  
* **Consignment Net Sum:** $${(parseFloat(quantity) * (parseFloat(priceVal.replace(/[^0-9.]/g, "")) || 8000)).toLocaleString() || "120,000"} USD  

---

### **REMARKS & SELLER COMPLIANCE STATEMENTS**
* **Quality Verification:** Standard moisture levels below 12%. Cargo inspected by Sucofindo at loading warehouse.  
* **Special Customer Clause:** ${notesVal ? notesVal : "No auxiliary client-specific remarks applied."}  

---
**Authorized Signatory:**  
*Indonesian Agricultural Export Board Liaison Office*
`;
        } else if (docTypeVal.toLowerCase().includes("packing")) {
          mockDocumentText = `
# COMMERCIAL PACKING LIST
**PT REMPAH NUSANTARA ABADI**  
*Exopilot Co-Op Group, Cargo Tower B-10, Tanjung Priok, Jakarta, Indonesia*  

---

### **PACKING SUMMARY BOARD**
* **Packing List No:** PL/EX/${new Date().getFullYear()}/${Math.floor(1000 + Math.random() * 9000)}  
* **Date:** ${dateToday}  
* **Associated Invoice Reference:** INV/2026/${Math.floor(100000 + Math.random() * 900000)}  
* **Vessel / Voyage:** Maersk Maluku v819  

---

### **PARTIES OF THE TRANSACTION**
**Consignor:** PT Rempah Nusantara Abadi, Jakarta, Indonesia  
**Consignee:** ${buyerName}, ${countryVal}  

---

### **CARGO PACKAGES SPECIFICATIONS**

| No. | Description of Goods | Bag Unit Weight | Net Volume Weight | Estimated Gross Weight | Type of Packing | Outer Cargo Marks |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **01** | **${commodity}** | 50.0 kg Net | ${quantity} | ${parseFloat(quantity) ? (parseFloat(quantity) * 1.02).toFixed(1) + " MT" : "12.2 MT"} | Double-Layer Gunny Jute Sacks | *EXOPILOT / ${buyerName.toUpperCase().replace(/\s+/g, "_")} / ${countryVal.toUpperCase()}* |

* **Total Number of Packages:** ${Math.floor((parseFloat(quantity) || 10) * 20)} Bags  
* **Container Loading Detail:** Hand-Stacked inside 1x 20FT General Purpose Sea Vessel Container  

---

### **REMARKS & SECURITY SIGN-OFF**
* **Ventilation Settings:** Moisture-absorbent desiccants distributed. Relative humidity in vessel maintained below 65%.  
* **Special Request Notes:** ${notesVal ? notesVal : "None. Goods comply with cargo transport code."}  

---
**Approved Cargo Handler:**  
*Port of Loading Lead Marine Supervisor, Tanjung Priok*
`;
        } else if (docTypeVal.toLowerCase().includes("order")) {
          mockDocumentText = `
# PURCHASE ORDER DRAFT
**ISSUED ON BEHALF OF: ${buyerName.toUpperCase()}**  
*Trade Operations & Strategic Sourcing Board, ${countryVal}*  

---

### **PURCHASE METRICS**
* **PO Number Reference:** PO-${countryVal.slice(0, 3).toUpperCase()}-2026-${Math.floor(10000 + Math.random() * 90000)}  
* **Date of Issue:** ${dateToday}  
* **Target Supplier:** PT Rempah Nusantara Abadi, Jakarta, Indonesia  

---

### **COMMODITY ACQUISITION TERMS**

| Commodity Requested | Specifications Required | Purchase Weight | Offer Price Target (FOB) | Total Estimated Deal (USD) |
| :--- | :--- | :--- | :--- | :--- |
| **${commodity}** | Standard Grade, Moisture Max 12% | ${quantity} | ${priceVal.includes("$") ? priceVal : "$" + priceVal + "/MT"} | $${(parseFloat(quantity) * (parseFloat(priceVal.replace(/[^0-9.]/g, "")) || 8000)).toLocaleString() || "120,000"} USD |

---

### **MANDATORY IMPORT COMPLIANCE CLAUSES**
1. **Quality Agency Mandate:** Full surveyor verification report by Sucofindo or SGS at Seller's expense.  
2. **Acceptable Packing:** Raw spices are to be stored in dry food-grade double jute gunny sacks.  
3. **Phytosanitary Protocol:** Seller must obtain official Phytosanitary Health Certification from the Indonesian Ministry of Agriculture.  
4. **Special Directives:** ${notesVal ? notesVal : "Apply standard B2B ocean transit requirements."}  

---
**Draft Prepared By:**  
*Sourcing Lead Officer, ${buyerName} Import Desk*
`;
        } else if (docTypeVal.toLowerCase().includes("email")) {
          mockDocumentText = `
### **FORMAL B2B EMAIL OUTBOUND**
**From:** PT Rempah Nusantara Abadi Export Division <export@exopilot.co>  
**To:** Procurement Sourcing Board <procurement@${buyerName.toLowerCase().replace(/[^a-z0-9]/g, "") || "buyer"}.com>  
**Cc:** trade-desk@exopilot.co  
**Subject:** B2B Spice Trade Arrangement Proposal // PT Rempah Nusantara Abadi -> ${buyerName} [Ref: ${serialRef}]  

---

Dear procurement directors of **${buyerName}**,

We hope this communication finds you well. 

As a primary Indonesian Agricultural Export partner operating under the **Exopilot Co-Op network**, we are pleased to present our official B2B trade offering regarding your interest in sourcing high-quality Indonesian **${commodity}** to your hubs in **${countryVal}**.

We have structured a formal allotment of **${quantity}** with a premium target pricing of **${priceVal.includes("$") ? priceVal : "$" + priceVal + "/MT"} FOB Indonesia**.

Our logistics division has integrated all your custom requirements:
> *${notesVal ? notesVal : "Standard prompt loading and Sucofindo pre-sailing phytosanitary clearances."}*

All our export grains and spice cloves are sourced directly from our co-operative smallholder networks in Maluku and Sulawesi Noord, ensuring competitive pricing and social traceability. 

We have attached the formal commercial contract drafts and SGS grading specifications for your assessment. Please let us know when your trade council is available for an introductory secure briefing call.

Warm and professional regards,

**Praisilia Anastasya**  
*Export Sales Director*   
**PT Rempah Nusantara Abadi (Exopilot Group)**  
*Jakarta Office Liaison*
`;
        } else if (docTypeVal.toLowerCase().includes("shipping")) {
          mockDocumentText = `
# SHIPPING INSTRUCTIONS (SI)
**PT REMPAH NUSANTARA ABADI**  
*Exopilot Co-Op Group, Cargo Tower B-10, Tanjung Priok, Jakarta, Indonesia*  

---

### **SI CORE PARSERS**
* **SI Ref Number:** SI/EX-2026-${Math.floor(1000 + Math.random() * 9000)}  
* **FBO Standard:** Port of Tanjung Priok (IDTPP)  
* **Discharge Port Target:** Principal Seaport, ${countryVal}  
* **Target Carrier Liner:** Maersk Sealink Cargo Services  

---

### **CO-OP CARGO PARTIES**
* **Shipper / Consignor:** PT Rempah Nusantara Abadi, Jakarta, Indonesia  
* **Consignee / Buyer:** ${buyerName}, ${countryVal}  
* **Notify Party:** Same as Consignee  

---

### **CARGO SUMMARY**
* **Declared Commodity:** Premium Indonesian **${commodity}**  
* **Declared Net Mass:** ${quantity}  
* **Declared Packaging:** ${Math.floor((parseFloat(quantity) || 10) * 20)} Bags on heat-treated export ISPM-15 standard wooden pallets  
* **Container Specifications:** 1x 20FT FCL dry cargo container  

---

### **SPECIAL CARRIER INSTRUCTIONS**
* **Temperature Guard:** Underdeck storage mandated to prevent relative moisture condensation. Temp range locked [15°C - 25°C].  
* **Specific Ocean Demands:** ${notesVal ? notesVal : "Standard maritime handling is adequate."}  

---
**Prepared By:**  
*Exopilot Maritime Dispatch Liaison*
`;
        } else if (docTypeVal.toLowerCase().includes("contract")) {
          mockDocumentText = `
# INTERNATIONAL TRADE SALE-PURCHASE CONTRACT
**DOCUMENT ID: RNA-EX-${countryVal.slice(0, 3).toUpperCase()}-${Math.floor(10000 + Math.random() * 90000)}**  

---

This agreement is entered on **${dateToday}** by and between:

**SELLER / EXPORTER:**  
**PT REMPAH NUSANTARA ABADI**  
Jakarta, Republic of Indonesia  

**BUYER / IMPORTER:**  
**${buyerName}**  
Headquartered in ${countryVal}  

---

### **ARTICLE 1: SUBJECT OF CONTRACT**
The Seller agrees to supply and sell, and the Buyer agrees to purchase and accept high-grade, premium certified **${commodity}** originating from direct agricultural smallholder cooperatives in Indonesia.

### **ARTICLE 2: QUANTITY AND TOLERANCE**
* **Net Quantity Volume Ordered:** ${quantity}  
* **Cargo Shipping Tolerance Range:** +/- 3% at loading port weight validation scales.  

### **ARTICLE 3: PRICE AND TERMS**
* **Price Basis:** ${priceVal.includes("$") ? priceVal : "$" + priceVal + "/MT"} FOB Indonesian Loading Ports.  
* **Total Estimated Value:** $${(parseFloat(quantity) * (parseFloat(priceVal.replace(/[^0-9.]/g, "")) || 8000)).toLocaleString() || "120,000"} USD  

### **ARTICLE 4: PAYMENT ASSURANCE**
Payment shall be made in USD by irrevocable, verified Letter of Credit (L/C) or advanced Telegraphic Transfer (T/T). 30% advance deposit required for mill reservation.

### **ARTICLE 5: QUALITY CHECKS & SPECIAL DEMANDS**
* The Seller will provide a formal Phytosanitary Certificate, Certificate of Origin (Form D/E/AK), and SGS Sucofindo Quality Certificate confirming moisture < 12%, mold-free.  
* **Special Client Compliance Notes:** ${notesVal ? notesVal : "Standard export provisions applied."}  

---

**For PT Rempah Nusantara Abadi (Seller):**  
*Praisilia Anastasya (Export Sales Director)*  

**For ${buyerName} (Buyer):**  
*Lead Sourcing Director Representative*
`;
        } else {
          // Quotation
          mockDocumentText = `
# FORMAL EXPORT QUOTATION
**EXOPILOT SMART EXPORT OFFICE**  
*Indonesian Spike Co-Operation Group*  
*Date: ${dateToday} | Ref: ${serialRef}*  

---

### **Recipient Information**
**To:** ${buyerName}  
**Format:** FOB International Shipments to ${countryVal}  

---

### **Quotation Breakdown**

| Spice Commodity | Quantity Ordered | Quotation Price (USD) | Origin country | Loading Port |
| :--- | :--- | :--- | :--- | :--- |
| **${commodity}** | ${quantity} | ${priceVal.includes("$") ? priceVal : "$" + priceVal + "/MT"} | Indonesia | Tanjung Priok (JAKARTA) |

---

### **Negotiation Notes & Custom Demands Addressed**
* **Special Buyer Requests:** ${notesVal ? notesVal : "No custom demands requested for this contract offer."}

---

### **Standard Export Terms & Conditions**
1. **Origin:** Maluku / North Sumatra, Republic of Indonesia (Premium Hand-Selected).
2. **Packaging:** Double-layer gunny bags (50kg net weight) or custom plywood cartons depending on export conditions.
3. **Payment Terms:** 30% advance Telegraphic Transfer (T/T), 70% against Scanned Bill of Lading (B/L) Documents.
4. **Estimated Shipping Time:** 14-20 Days following pre-export phytosanitary inspection approval.
5. **Quality Standard:** Free from mold, moisture < 12%, admixture < 1.5%. Full Indonesian Surveyor Certificate (SGS/Sucofindo) supplied at loading port.

---
**Prepared By:** Exopilot Cargo AI  
**Approved By:** Indonesian Agricultural Export Board Liaison Office
`;
        }

        // Prepend notice
        const fallbackText = `
*This document template was generated by Exopilot's high-fidelity offline layout generator because live **GEMINI_API_KEY** was not detected in this session's sandbox environment. Paste your API key in settings to watch our tailored spice model live-generate layouts.*

---

${mockDocumentText.trim()}
`;
        return res.json({ document: fallbackText, note: "Loaded offline template (Gemini API key missing)." });
      }

      // Lazy initialization of GoogleGenAI SDK as instructed
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });

      const promptPhrase = `
You are an expert Indonesian Spice Export Director and Sales Consultant representing PT Rempah Nusantara Abadi (Exopilot Co-Op Group, Jakarta, Indonesia).
Generate a highly detailed, professional, B2B export document matching the requested type: "${docTypeVal}".
The document must be written in English and formatted in clean, professional Markdown.

Use these parameters precisely:
- **Requested Document Type:** ${docTypeVal} (Format exactly as this type! Options: Invoice, Packing List, Quotation, Purchase Order Draft, Formal Email, Shipping Instruction, Contract Template)
- **Buyer/Importer:** ${buyerName}
- **Destination Country:** ${countryVal}
- **Commodity/Spice:** ${commodity}
- **Quantity Volume:** ${quantity}
- **Target FOB/CFR/CIF Price:** ${priceVal}
- **Specific Negotiation Notes & Customer Demands:** ${notesVal || "None Specified"}

Guidelines for the specific document type "${docTypeVal}":
- If Commercial Invoice: Include detailed address, random INV reference, FOB Tanjung Priok, precise row calculations, mock Bank Transfer payment instructions.
- If Packing List: Elaborate net vs gross packaging weights, outer shipping marks, total boxes/bags stacks.
- If Purchase Order Draft: Formulate it from ${buyerName}'s perspective, ordering the cargo from PT Rempah Nusantara Abadi, including standard inspection requirements.
- If Formal Email: Start with deep professional greetings, pitch the spice lot, state direct cost terms, highlight the custom demands (${notesVal}) addressed, and request an intro call.
- If Shipping Instruction: Write a clear dispatch note to carrier Maersk highlighting ventilation parameters.
- If Contract Template: Build full, legally binding sale-purchase clauses (Article 1 to 7) with place for signatures.
- If Quotation: Present a polite sales offer letter accompanied by standard spice moisture specifications and quality certifications.

Always address the buyer's negotiation clauses or special demands: "${notesVal}" seamlessly.

Format the output inside a magnificent, neat markdown flow. Keep layout extremely clean, readable, and strictly B2B professional. Do not surround the markdown block with conversational meta-chat or pleasantries. Just return the raw markdown content itself.
`;

      const geminiResponse = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: promptPhrase,
      });

      const generatedText = geminiResponse.text || "Failed to generate document.";
      res.json({ document: generatedText });

    } catch (error: any) {
      console.error("Gemini API Error:", error);
      res.status(500).json({ error: "Failed to query Gemini assistant: " + (error?.message || error) });
    }
  });

  // 4. API to manage/remove entries (extra utility for live interactive dashboard mockup)
  app.delete("/api/inquiry/:id", (req, res) => {
    const { id } = req.params;
    inquiries = inquiries.filter(i => i.id !== id);
    res.json({ message: "Inquiry deleted successfully", inquiries });
  });

  // 5. API to manage Suppliers cooperative networks (nama, lokasi, kapasitas_supply)
  app.get("/api/suppliers", (req, res) => {
    res.json(suppliers);
  });

  app.post("/api/supplier", (req, res) => {
    const { name, location, supplyCapacity } = req.body;
    if (!name || typeof name !== "string" || name.trim() === "") {
      return res.status(400).json({ error: "Supplier Name is required." });
    }
    if (!location || typeof location !== "string" || location.trim() === "") {
      return res.status(400).json({ error: "Supplier Location is required." });
    }
    if (!supplyCapacity || typeof supplyCapacity !== "string" || supplyCapacity.trim() === "") {
      return res.status(400).json({ error: "Supply Capacity is required." });
    }

    const newSupplier: Supplier = {
      id: `sup_${Date.now()}`,
      name: name.trim(),
      location: location.trim(),
      supplyCapacity: supplyCapacity.trim(),
      createdAt: new Date().toISOString().split("T")[0],
    };

    suppliers.unshift(newSupplier);
    res.status(201).json({
      message: "Spice supplier cooperative logged successfully",
      supplier: newSupplier,
      suppliers,
    });
  });

  app.delete("/api/supplier/:id", (req, res) => {
    const { id } = req.params;
    suppliers = suppliers.filter(s => s.id !== id);
    res.json({ message: "Supplier deleted successfully", suppliers });
  });

  // Vite middleware setup for Development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Exopilot Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
