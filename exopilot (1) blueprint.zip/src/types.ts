export interface Inquiry {
  id: string;
  buyerName: string;
  country: string;
  product: string;
  quantity: string;
  price: string;
  status: "New" | "Negotiating" | "Closed";
  date: string;
}

export interface Shipment {
  id: string;
  containerNumber: string;
  shippingLine: string;
  commodity: string;
  status: "Customs" | "On Vessel" | "Arrived";
  etd: string;
  eta: string;
}

export interface DashboardSummary {
  totalInquiries: number;
  activeShipments: number;
  closedDeals: number;
  pipelineValue: string;
  sourcingSuppliers: number;
  monthlyIncreaseRate: string;
}

export type ActiveSection = "live-app" | "blueprints";
export type BlueprintTab = "sql-schema" | "go-backend" | "nextjs-dashboard" | "nextjs-api-route";
export type AppMenuSubTab = "dashboard" | "inquiries" | "shipments" | "doc-generator";
