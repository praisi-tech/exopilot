import React, { useState, useEffect } from "react";
import { jsPDF } from "jspdf";
import { HighFidelityPaperPreview } from "./components/HighFidelityPaperPreview";
import {
  LayoutDashboard,
  ClipboardList,
  Ship,
  FileText,
  Plus,
  Compass,
  TrendingUp,
  MapPin,
  Globe,
  CheckCircle2,
  AlertCircle,
  FileCode,
  Copy,
  Check,
  PlusCircle,
  Trash2,
  Sparkles,
  Loader2,
  ArrowRight,
  ChevronRight,
  Database,
  Terminal,
  Layers,
  ChevronDown,
  Scale,
  Coins,
  Calculator,
  Users,
  Warehouse,
  Search,
  User,
  Lock,
  Mail,
  Building,
  Eye,
  EyeOff,
  LogOut,
  Settings
} from "lucide-react";

interface Inquiry {
  id: string;
  buyerName: string;
  country: string;
  product: string;
  quantity: string;
  price: string;
  status: "New" | "Negotiating" | "Closed";
  date: string;
  negotiationNotes?: string;
}

interface Shipment {
  id: string;
  containerNumber: string;
  shippingLine: string;
  commodity: string;
  status: "Customs" | "On Vessel" | "Arrived";
  etd: string;
  eta: string;
}

interface Supplier {
  id: string;
  name: string;
  location: string;
  supplyCapacity: string;
  createdAt: string;
}

interface DashboardSummary {
  totalInquiries: number;
  activeShipments: number;
  closedDeals: number;
  pipelineValue: string;
  sourcingSuppliers: number;
  monthlyIncreaseRate: string;
}

// ---------------------------------------------------------
// Boilerplate texts for the Developer view tab
// ---------------------------------------------------------
const sqlSchemaCode = `-- ====================================================================
-- EXOPILOT DB SCHEMA (Supabase / PostgreSQL DDL)
-- Designed for Indonesian Spice Export SMEs
-- Supported: Row Level Security (RLS), Auto-Audit Timestamps, constraints
-- Mapping auth.users (Firebase UID matched via auth.users id or as custom uid)
-- ====================================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- 1. PROFILES TABLE
-- Maps Firebase authenticated users into our relational database schema.
create table public.profiles (
    id uuid primary key, -- Foreign Key to Firebase UID or auth.users
    company_name varchar(255) not null,
    main_commodity varchar(100) not null default 'Nutmeg',
    phone_number varchar(50),
    legal_entity_type varchar(50) default 'CV', -- Indonesian business types e.g. CV, PT, UD
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 2. BUYER INQUIRIES TABLE
-- Stores B2B requests from global spice purchasers (nutmeg, cloves, mace, cinnamon, etc.)
create table public.buyer_inquiries (
    id uuid default uuid_generate_v4() primary key,
    user_id uuid not null references public.profiles(id) on delete cascade,
    buyer_name varchar(255) not null,
    country varchar(100) not null,
    product varchar(150) not null, -- e.g., 'Nutmeg ABCD Grade', 'Lal Pari Cloves'
    quantity varchar(100) not null, -- e.g., '15 MT (Metric Tons)'
    status varchar(50) not null default 'New',
    price_offer varchar(50) default 'Negotiable',
    notes text,
    negotiation_notes text, -- Catatan negosiasi ekspor rincian penawaran
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
    
    constraint check_inquiry_status check (status in ('New', 'Negotiating', 'Closed'))
);

-- 3. SHIPMENT TRACKER TABLE
-- Tracks international sea cargo containers, ETDs, ETAs, and legal document stages
create table public.shipment_tracker (
    id uuid default uuid_generate_v4() primary key,
    user_id uuid not null references public.profiles(id) on delete cascade,
    container_number varchar(50) not null, -- Standard shipping code
    shipping_line varchar(100) not null, -- e.g., 'Evergreen', 'Maersk', 'OOCL'
    status varchar(50) not null default 'Customs',
    commodity varchar(150) not null,
    etd date not null, 
    eta date not null, 
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
    
    constraint check_shipment_status check (status in ('Customs', 'On Vessel', 'Arrived'))
);

-- 4. SUPPLIERS TABLE
-- Tracks local cooperatives, farm clusters, and spice growers supplying product for export
create table public.suppliers (
    id uuid default uuid_generate_v4() primary key,
    user_id uuid not null references public.profiles(id) on delete cascade,
    name varchar(255) not null,         -- Nama supplier (SME partner)
    location varchar(255) not null,     -- Lokasi/Asal supplier (e.g. Banda Neira, Ambon)
    supply_capacity varchar(100) not null, -- Kapasitas supply (e.g. 50 MT / Month)
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Auto Updated_At triggers and RLS definitions omitted for brevity...`;

const goBackendCode = `package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"sync"
	"time"
)

type Inquiry struct {
	ID        string    \`json:"id"\`
	BuyerName string    \`json:"buyer_name"\`
	Country   string    \`json:"country"\`
	Product   string    \`json:"product"\`
	Quantity  string    \`json:"quantity"\`
	Status    string    \`json:"status"\`
	CreatedAt time.Time \`json:"created_at"\`
}

type Shipment struct {
	ID              string    \`json:"id"\`
	ContainerNumber string    \`json:"container_number"\`
	ShippingLine    string    \`json:"shipping_line"\`
	Status          string    \`json:"status"\`
	Commodity       string    \`json:"commodity"\`
	ETD             time.Time \`json:"etd"\`
	ETA             time.Time \`json:"eta"\`
}

type StatsResponse struct {
	TotalInquiries   int        \`json:"total_inquiries"\`
	ActiveContainers int        \`json:"active_containers"\`
	Inquiries        []Inquiry  \`json:"inquiries"\`
	Shipments        []Shipment \`json:"shipments"\`
}

type ExopilotServer struct {
	mu        sync.RWMutex
	inquiries []Inquiry
	shipments []Shipment
}

func (s *ExopilotServer) HandleGetDashboard(w http.ResponseWriter, r *http.Request) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	activeContainers := 0
	for _, ship := range s.shipments {
		if ship.Status != "Arrived" {
			activeContainers++
		}
	}

	response := StatsResponse{
		TotalInquiries:   len(s.inquiries),
		ActiveContainers: activeContainers,
		Inquiries:        s.inquiries,
		Shipments:        s.shipments,
	}

	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(response)
}

func (s *ExopilotServer) HandlePostInquiry(w http.ResponseWriter, r *http.Request) {
	var req struct {
		BuyerName string \`json:"buyer_name"\`
		Country   string \`json:"country"\`
		Product   string \`json:"product"\`
		Quantity  string \`json:"quantity"\`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	newInquiry := Inquiry{
		ID:        fmt.Sprintf("inq_%d", time.Now().UnixNano()),
		BuyerName: req.BuyerName,
		Country:   req.Country,
		Product:   req.Product,
		Quantity:  req.Quantity,
		Status:    "New",
		CreatedAt: time.Now(),
	}
	s.inquiries = append([]Inquiry{newInquiry}, s.inquiries...)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	_ = json.NewEncoder(w).Encode(newInquiry)
}`;

const nextjsPageCode = `// app/dashboard/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import { LayoutDashboard, ClipboardSpreadsheet, Ship, FileText, Plus, Globe } from "lucide-react";

export default function ExopilotDashboard() {
  const [inquiries, setInquiries] = useState([]);
  const [summary, setSummary] = useState({ totalInquiries: 0, activeShipments: 0 });

  useEffect(() => {
    fetch("/api/dashboard")
      .then(res => res.json())
      .then(data => {
        setInquiries(data.inquiries || []);
        setSummary(data.summary || {});
      });
  }, []);

  return (
    <div className="flex h-screen bg-[#F6F8FC]">
      <aside className="w-64 bg-white border-r p-6">
        <h1 className="font-extrabold text-lg text-indigo-950">EXOPILOT</h1>
        <p className="text-[10px] text-indigo-600 font-bold uppercase tracking-wider">Spice Trade OS</p>
        <nav className="mt-8 space-y-2">
          {["Dashboard", "Inquiries", "Shipments"].map(tab => (
            <button key={tab} className="w-full flex gap-3 text-sm font-semibold p-3 rounded-lg text-gray-600 hover:bg-gray-50 text-left">
              <span>{tab}</span>
            </button>
          ))}
        </nav>
      </aside>

      <main className="flex-1 p-8 space-y-8 overflow-y-auto">
        <h2 className="text-2xl font-black text-gray-900">Cargo Management Gateway</h2>
        
        <div className="grid grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border">
            <p className="text-xs font-bold text-gray-400">Total Inquiries</p>
            <p className="text-3xl font-black mt-2">{summary.totalInquiries}</p>
          </div>
        </div>
      </main>
    </div>
  );
}`;

const nextjsApiCode = `// app/api/generate-document/route.ts
import { NextRequest, NextResponse } from "next/server";
import { GoogleGenAI } from "@google/genai";

export async function POST(req: NextRequest) {
  try {
    const { buyerName, commodity, quantity, price } = await req.json();

    if (!buyerName || !commodity || !quantity) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 });
    }

    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
    
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: \`Generate formal quotation letter for Indonesian Export Spice \${commodity} to \${buyerName}...\`,
    });

    return NextResponse.json({ success: true, document: response.text });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}`;

export default function App() {
  const [activeSection, setActiveSection] = useState<"live-app" | "blueprints">("live-app");
  const [activeAppTab, setActiveAppTab] = useState<"dashboard" | "inquiries" | "suppliers" | "shipments" | "doc-generator" | "settings">("dashboard");
  const [activeBlueprintTab, setActiveBlueprintTab] = useState<"sql-schema" | "go-backend" | "nextjs-dashboard" | "nextjs-api-route">("sql-schema");

  // Dynamic Authentication management state
  const [currentUser, setCurrentUser] = useState<{
    name: string;
    email: string;
    businessName: string;
  } | null>(() => {
    const saved = localStorage.getItem("exo_session_user");
    if (saved) {
      if (saved === "explicit_logout") {
        return null;
      }
      try {
        return JSON.parse(saved);
      } catch (err) {
        return null;
      }
    }
    // Default to genuine SME partner session (Praisilia Anastasya) so the SME app is immediately visible on first load
    const defaultUser = {
      name: "Praisilia Anastasya",
      email: "praisilia.anastasya@gmail.com",
      businessName: "CV Exporter Assistant",
    };
    localStorage.setItem("exo_session_user", JSON.stringify(defaultUser));
    return defaultUser;
  });

  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [authForm, setAuthForm] = useState({
    name: "",
    email: "",
    password: "",
    businessName: "",
    specialization: "Cloves & Nutmeg",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  
  // Real Dynamic States
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [summary, setSummary] = useState<DashboardSummary>({
    totalInquiries: 0,
    activeShipments: 0,
    closedDeals: 0,
    pipelineValue: "$0",
    sourcingSuppliers: 8,
    monthlyIncreaseRate: "+0.0%",
  });

  // Loading & Interactivity states
  const [isPageLoading, setIsPageLoading] = useState(true);
  const [isGeneratingDoc, setIsGeneratingDoc] = useState(false);
  const [generatedDoc, setGeneratedDoc] = useState("");
  const [pdfPreviewUrl, setPdfPreviewUrl] = useState<string | null>(null);
  const [previewTab, setPreviewTab] = useState<"pdf" | "markdown">("pdf");
  const [copiedText, setCopiedText] = useState("");

  // New Quick Assistant tools modals
  const [showCalcModal, setShowCalcModal] = useState(false);
  const [showConverterModal, setShowConverterModal] = useState(false);

  // Container Calculator inputs
  const [calcForm, setCalcForm] = useState({
    bagLength: 60, // cm
    bagWidth: 40,  // cm
    bagHeight: 25, // cm
    bagWeight: 50, // kg
  });

  // Currency Converter states
  const [convForm, setConvForm] = useState({
    amount: "1000",
    fromCurrency: "USD",
    toCurrency: "IDR",
  });
  
  // Add inquiry form
  const [showAddModal, setShowAddModal] = useState(false);
  const [newInquiryForm, setNewInquiryForm] = useState({
    buyerName: "",
    country: "",
    product: "Nutmeg (ABCD Grade)",
    quantity: "15 MT",
    price: "$8,500/MT",
    negotiationNotes: "",
  });
  const [isSubmittingInquiry, setIsSubmittingInquiry] = useState(false);

  // Add supplier form
  const [showAddSupplierModal, setShowAddSupplierModal] = useState(false);
  const [newSupplierForm, setNewSupplierForm] = useState({
    name: "",
    location: "",
    supplyCapacity: "",
  });
  const [isSubmittingSupplier, setIsSubmittingSupplier] = useState(false);

  // Search input tracking
  const [inquirySearch, setInquirySearch] = useState("");
  const [supplierSearch, setSupplierSearch] = useState("");

  // Doc Generator Selector form
  const [selectedInquiryId, setSelectedInquiryId] = useState("");
  const [customDocForm, setCustomDocForm] = useState({
    docType: "Quotation",
    buyerName: "Dutch Botanical Bulk",
    commodity: "Cloves (Lal Pari Grade)",
    quantity: "12 MT",
    price: "$9,100/MT",
    destinationCountry: "Netherlands",
    negotiationNotes: "Client requests phytosanitary pre-verification, prompt loading from port of Belawan."
  });

  // Alerts feedback
  const [systemAlert, setSystemAlert] = useState<{ message: string; type: "success" | "error" | null }>({
    message: "",
    type: null,
  });

  // Fetch dashboard summary
  const fetchDashboardData = async () => {
    try {
      const response = await fetch("/api/dashboard");
      if (response.ok) {
        const data = await response.json();
        setInquiries(data.inquiries || []);
        setShipments(data.shipments || []);
        setSuppliers(data.suppliers || []);
        setSummary(data.summary || {
          totalInquiries: 0,
          activeShipments: 0,
          closedDeals: 0,
          pipelineValue: "$0",
          sourcingSuppliers: 8,
          monthlyIncreaseRate: "+12%",
        });
      }
    } catch (err) {
      console.error("Error reading live backend API:", err);
    } finally {
      setIsPageLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Update selected default values when an inquiry is selected
  useEffect(() => {
    if (selectedInquiryId) {
      const matched = inquiries.find(i => i.id === selectedInquiryId);
      if (matched) {
        setCustomDocForm(prev => ({
          ...prev,
          buyerName: matched.buyerName,
          commodity: matched.product,
          quantity: matched.quantity,
          price: matched.price,
          destinationCountry: matched.country || "Netherlands",
          negotiationNotes: matched.negotiationNotes || "",
        }));
      }
    }
  }, [selectedInquiryId, inquiries]);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(""), 2000);
  };

  const submitInquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newInquiryForm.buyerName || !newInquiryForm.country) {
      setSystemAlert({ message: "Please fill out all key client metrics.", type: "error" });
      return;
    }
    
    setIsSubmittingInquiry(true);
    try {
      const res = await fetch("/api/inquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          buyerName: newInquiryForm.buyerName,
          country: newInquiryForm.country,
          product: newInquiryForm.product,
          quantity: newInquiryForm.quantity,
          price: newInquiryForm.price,
          status: "New",
          negotiationNotes: newInquiryForm.negotiationNotes
        })
      });

      if (res.ok) {
        const result = await res.json();
        setInquiries(result.inquiries || []);
        // Trigger quick feedback alert
        setSystemAlert({ message: "Inquiry logged to Indonesian Co-Op cargo pipeline!", type: "success" });
        setShowAddModal(false);
        setNewInquiryForm({
          buyerName: "",
          country: "",
          product: "Nutmeg (ABCD Grade)",
          quantity: "15 MT",
          price: "$8,500/MT",
          negotiationNotes: "",
        });
        fetchDashboardData();
      } else {
        const errObj = await res.json();
        setSystemAlert({ message: errObj.error || "Failed to save record.", type: "error" });
      }
    } catch (e: any) {
      setSystemAlert({ message: "Database connection timed out or offline.", type: "error" });
    } finally {
      setIsSubmittingInquiry(false);
      setTimeout(() => setSystemAlert({ message: "", type: null }), 4000);
    }
  };

  const deleteInquiry = async (id: string) => {
    if (!confirm("Are you sure you want to remove this export inquiry from active workflow tracking?")) return;
    try {
      const res = await fetch(`/api/inquiry/${id}`, { method: "DELETE" });
      if (res.ok) {
        setSystemAlert({ message: "Inquiry purged successfully.", type: "success" });
        fetchDashboardData();
      }
    } catch (e) {
      console.error(e);
    }
    setTimeout(() => setSystemAlert({ message: "", type: null }), 3000);
  };

  const submitSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSupplierForm.name || !newSupplierForm.location || !newSupplierForm.supplyCapacity) {
      setSystemAlert({ message: "Please fill out all supplier metrics.", type: "error" });
      return;
    }

    setIsSubmittingSupplier(true);
    try {
      const res = await fetch("/api/supplier", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newSupplierForm.name,
          location: newSupplierForm.location,
          supplyCapacity: newSupplierForm.supplyCapacity,
        })
      });

      if (res.ok) {
        const result = await res.json();
        setSuppliers(result.suppliers || []);
        setSystemAlert({ message: "Spice supplier cooperative registered successfully!", type: "success" });
        setShowAddSupplierModal(false);
        setNewSupplierForm({
          name: "",
          location: "",
          supplyCapacity: "",
        });
        fetchDashboardData();
      } else {
        const errObj = await res.json();
        setSystemAlert({ message: errObj.error || "Failed to register supplier.", type: "error" });
      }
    } catch (err: any) {
      setSystemAlert({ message: "Database connection mapping offline or timed out.", type: "error" });
    } finally {
      setIsSubmittingSupplier(false);
      setTimeout(() => setSystemAlert({ message: "", type: null }), 4000);
    }
  };

  const deleteSupplier = async (id: string) => {
    if (!confirm("Are you sure you want to remove this spice supplier from active sourcing networks?")) return;
    try {
      const res = await fetch(`/api/supplier/${id}`, { method: "DELETE" });
      if (res.ok) {
        setSystemAlert({ message: "Spice supplier purged successfully.", type: "success" });
        fetchDashboardData();
      }
    } catch (err) {
      console.error(err);
    }
    setTimeout(() => setSystemAlert({ message: "", type: null }), 3000);
  };

  const generateExportQuotation = async () => {
    setIsGeneratingDoc(true);
    setGeneratedDoc("");
    try {
      const res = await fetch("/api/generate-document", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          docType: customDocForm.docType,
          buyerName: customDocForm.buyerName,
          commodity: customDocForm.commodity,
          quantity: customDocForm.quantity,
          price: customDocForm.price,
          destinationCountry: customDocForm.destinationCountry,
          negotiationNotes: customDocForm.negotiationNotes || ""
        })
      });

      if (res.ok) {
        const rData = await res.json();
        setGeneratedDoc(rData.document);
        setSystemAlert({ message: `${customDocForm.docType} formulated successfully!`, type: "success" });
      } else {
        const rErr = await res.json();
        setSystemAlert({ message: rErr.error || "API generation error", type: "error" });
      }
    } catch (err) {
      setSystemAlert({ message: "Gemini server response failed.", type: "error" });
    } finally {
      setIsGeneratingDoc(false);
      setTimeout(() => setSystemAlert({ message: "", type: null }), 4000);
    }
  };

  const exportToPDF = () => {
    if (!generatedDoc) return;
    try {
      const doc = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4"
      });

      // Page parameters: A4 is 210 x 297 mm
      const margin = 20;
      const pageWidth = 210;
      const pageHeight = 297;
      const contentWidth = pageWidth - (margin * 2);

      let y = 25;

      // Draw header banner
      doc.setFillColor(30, 41, 59); // deep slate slate-800
      doc.rect(margin, y, contentWidth, 20, "F");

      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(13);
      doc.text("EXOPILOT SMART EXPORT OFFICE", margin + 6, y + 8);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(203, 213, 225); // slate-300
      doc.text("OFFICIAL B2B SPICE QUOTATION CONTRACT OFFER", margin + 6, y + 14);

      y += 28;

      const lines = generatedDoc.split("\n");

      // Draw content line by line
      for (let i = 0; i < lines.length; i++) {
        const rawLine = lines[i];
        let trimmed = rawLine.trim();

        // 1. Horizontal Rules (---)
        if (trimmed === "---") {
          if (y + 10 > 270) {
            doc.addPage();
            y = 25;
          }
          doc.setDrawColor(226, 232, 240); // slate-200
          doc.setLineWidth(0.5);
          doc.line(margin, y, margin + contentWidth, y);
          y += 8;
          continue;
        }

        // Skip blank lines but add spacing
        if (trimmed === "") {
          y += 4;
          continue;
        }

        // 2. Headings
        if (trimmed.startsWith("# ")) {
          const text = trimmed.substring(2).replace(/\*\*/g, "");
          if (y + 12 > 270) {
            doc.addPage();
            y = 25;
          }
          doc.setFont("helvetica", "bold");
          doc.setFontSize(14);
          doc.setTextColor(15, 23, 42); // slate-900
          doc.text(text, margin, y);
          y += 10;
          continue;
        }

        if (trimmed.startsWith("## ") || trimmed.startsWith("### ")) {
          const depth = trimmed.startsWith("## ") ? 3 : 4;
          const text = trimmed.substring(depth).replace(/\*\*/g, "");
          if (y + 10 > 270) {
            doc.addPage();
            y = 25;
          }
          doc.setFont("helvetica", "bold");
          doc.setFontSize(11);
          doc.setTextColor(30, 41, 59); // slate-800
          doc.text(text, margin, y);
          y += 7;
          continue;
        }

        // 3. Table Rows
        if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
          // If it's a separator line (e.g. | :--- | :--- |), ignore it
          if (trimmed.includes("---") || trimmed.includes("-:-")) {
            continue;
          }

          const columns = trimmed
            .split("|")
            .map(col => col.trim().replace(/\*\*/g, ""))
            .filter((_, idx, arr) => idx > 0 && idx < arr.length - 1);

          if (columns.length > 0) {
            if (y + 10 > 270) {
              doc.addPage();
              y = 25;
            }

            // Simple responsive column layout with grid math
            const colWidth = contentWidth / columns.length;
            doc.setFont("helvetica", "normal");
            doc.setFontSize(8);
            doc.setTextColor(51, 65, 85); // slate-700

            // Draw a subtle border bottom for rows
            doc.setDrawColor(241, 245, 249); // slate-100
            doc.line(margin, y + 2, margin + contentWidth, y + 2);

            for (let c = 0; c < columns.length; c++) {
              const text = columns[c];
              doc.text(text, margin + (c * colWidth) + 1, y);
            }
            y += 7;
          }
          continue;
        }

        // 4. Bullets
        if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
          const bulletText = trimmed.substring(2).replace(/\*\*/g, "");
          if (y + 8 > 270) {
            doc.addPage();
            y = 25;
          }
          doc.setFont("helvetica", "normal");
          doc.setFontSize(9);
          doc.setTextColor(71, 85, 105); // slate-600
          
          doc.setFillColor(30, 41, 59);
          doc.circle(margin + 2, y - 1, 0.7, "F");

          const splitText = doc.splitTextToSize(bulletText, contentWidth - 8);
          for (let s = 0; s < splitText.length; s++) {
            if (y + 6 > 270) {
              doc.addPage();
              y = 25;
            }
            doc.text(splitText[s], margin + 6, y);
            y += 5;
          }
          continue;
        }

        // 5. Standard Paragraph Lines with Bold Parsing Support
        const normalText = trimmed.replace(/\*\*/g, "");
        if (normalText) {
          doc.setFont("helvetica", "normal");
          doc.setFontSize(9);
          doc.setTextColor(71, 85, 105); // slate-600

          const splitText = doc.splitTextToSize(normalText, contentWidth);
          for (let s = 0; s < splitText.length; s++) {
            if (y + 6 > 270) {
              doc.addPage();
              y = 25;
            }
            doc.text(splitText[s], margin, y);
            y += 5;
          }
        }
      }

      // Add elegant Footer containing page metadata to each page
      const pageCount = doc.getNumberOfPages();
      for (let p = 1; p <= pageCount; p++) {
        doc.setPage(p);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(7.5);
        doc.setTextColor(148, 163, 184); // slate-400
        doc.text(
          `Document Ref: EX-${new Date().getFullYear()}-${customDocForm.buyerName.toUpperCase().replace(/[^a-zA-Z0-9]/g, '').slice(0, 10)}`,
          margin,
          pageHeight - 12
        );
        doc.text(
          `Page ${p} of ${pageCount}`,
          pageWidth - margin - 15,
          pageHeight - 12
        );
      }

      doc.save(`Exopilot_${customDocForm.docType.replace(/\s+/g, "_")}_${customDocForm.buyerName.replace(/\s+/g, "_")}.pdf`);
      setSystemAlert({ message: `PDF ${customDocForm.docType} downloaded successfully!`, type: "success" });
    } catch (err: any) {
      console.error(err);
      setSystemAlert({ message: "Could not compile PDF payload structure.", type: "error" });
    } finally {
      setTimeout(() => setSystemAlert({ message: "", type: null }), 3000);
    }
  };

  // Live PDF preview compiler that executes on document changes
  useEffect(() => {
    let activeUrl: string | null = null;
    if (generatedDoc) {
      try {
        const doc = new jsPDF({
          orientation: "portrait",
          unit: "mm",
          format: "a4"
        });

        const margin = 20;
        const pageWidth = 210;
        const pageHeight = 297;
        const contentWidth = pageWidth - (margin * 2);

        let y = 25;

        // Draw header banner matching standard B2B PDF Layout exports
        doc.setFillColor(30, 41, 59); // deep slate/coop slate
        doc.rect(margin, y, contentWidth, 20, "F");

        doc.setTextColor(255, 255, 255);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(13);
        doc.text("EXOPILOT SMART EXPORT OFFICE", margin + 6, y + 8);

        doc.setFont("helvetica", "normal");
        doc.setFontSize(8);
        doc.setTextColor(203, 213, 225); // slate-300
        doc.text("OFFICIAL B2B SPICE QUOTATION CONTRACT OFFER", margin + 6, y + 14);

        y += 28;

        const lines = generatedDoc.split("\n");

        for (let i = 0; i < lines.length; i++) {
          const rawLine = lines[i];
          let trimmed = rawLine.trim();

          if (trimmed === "---") {
            if (y + 10 > 270) {
              doc.addPage();
              y = 25;
            }
            doc.setDrawColor(226, 232, 240); // slate-200
            doc.setLineWidth(0.5);
            doc.line(margin, y, margin + contentWidth, y);
            y += 8;
            continue;
          }

          if (trimmed === "") {
            y += 4;
            continue;
          }

          if (trimmed.startsWith("# ")) {
            const text = trimmed.substring(2).replace(/\*\*/g, "");
            if (y + 12 > 270) {
              doc.addPage();
              y = 25;
            }
            doc.setFont("helvetica", "bold");
            doc.setFontSize(14);
            doc.setTextColor(15, 23, 42); // slate-900
            doc.text(text, margin, y);
            y += 10;
            continue;
          }

          if (trimmed.startsWith("## ") || trimmed.startsWith("### ")) {
            const depth = trimmed.startsWith("## ") ? 3 : 4;
            const text = trimmed.substring(depth).replace(/\*\*/g, "");
            if (y + 10 > 270) {
              doc.addPage();
              y = 25;
            }
            doc.setFont("helvetica", "bold");
            doc.setFontSize(11);
            doc.setTextColor(30, 41, 59); // slate-800
            doc.text(text, margin, y);
            y += 7;
            continue;
          }

          if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
            if (trimmed.includes("---") || trimmed.includes("-:-")) {
              continue;
            }

            const columns = trimmed
              .split("|")
              .map(col => col.trim().replace(/\*\*/g, ""))
              .filter((_, idx, arr) => idx > 0 && idx < arr.length - 1);

            if (columns.length > 0) {
              if (y + 10 > 270) {
                doc.addPage();
                y = 25;
              }

              const colWidth = contentWidth / columns.length;
              doc.setFont("helvetica", "normal");
              doc.setFontSize(8);
              doc.setTextColor(51, 65, 85);

              doc.setDrawColor(241, 245, 249);
              doc.line(margin, y + 2, margin + contentWidth, y + 2);

              for (let c = 0; c < columns.length; c++) {
                const text = columns[c];
                doc.text(text, margin + (c * colWidth) + 1, y);
              }
              y += 7;
            }
            continue;
          }

          if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
            const bulletText = trimmed.substring(2).replace(/\*\*/g, "");
            if (y + 8 > 270) {
              doc.addPage();
              y = 25;
            }
            doc.setFont("helvetica", "normal");
            doc.setFontSize(9);
            doc.setTextColor(71, 85, 105);

            doc.setFillColor(30, 41, 59);
            doc.circle(margin + 2, y - 1, 0.7, "F");

            const splitText = doc.splitTextToSize(bulletText, contentWidth - 8);
            for (let s = 0; s < splitText.length; s++) {
              if (y + 6 > 270) {
                doc.addPage();
                y = 25;
              }
              doc.text(splitText[s], margin + 6, y);
              y += 5;
            }
            continue;
          }

          const normalText = trimmed.replace(/\*\*/g, "");
          if (normalText) {
            doc.setFont("helvetica", "normal");
            doc.setFontSize(9);
            doc.setTextColor(71, 85, 105);

            const splitText = doc.splitTextToSize(normalText, contentWidth);
            for (let s = 0; s < splitText.length; s++) {
              if (y + 6 > 270) {
                doc.addPage();
                y = 25;
              }
              doc.text(splitText[s], margin, y);
              y += 5;
            }
          }
        }

        const pageCount = doc.getNumberOfPages();
        for (let p = 1; p <= pageCount; p++) {
          doc.setPage(p);
          doc.setFont("helvetica", "normal");
          doc.setFontSize(7.5);
          doc.setTextColor(148, 163, 184);
          doc.text(
            `Document Ref: EX-${new Date().getFullYear()}-${customDocForm.buyerName.toUpperCase().replace(/[^a-zA-Z0-9]/g, '').slice(0, 10)}`,
            margin,
            pageHeight - 12
          );
          doc.text(
            `Page ${p} of ${pageCount}`,
            pageWidth - margin - 15,
            pageHeight - 12
          );
        }

        const blob = doc.output("blob");
        activeUrl = URL.createObjectURL(blob);
        setPdfPreviewUrl(activeUrl);
      } catch (err) {
        console.error("Failed to generate PDF Blob preview", err);
      }
    } else {
      setPdfPreviewUrl(null);
    }

    return () => {
      if (activeUrl) {
        URL.revokeObjectURL(activeUrl);
      }
    };
  }, [generatedDoc, customDocForm.buyerName, customDocForm.docType]);

  const filteredInquiries = inquiries.filter(inq => {
    const q = inquirySearch.toLowerCase();
    return (
      inq.buyerName.toLowerCase().includes(q) ||
      inq.country.toLowerCase().includes(q) ||
      inq.product.toLowerCase().includes(q) ||
      inq.status.toLowerCase().includes(q)
    );
  });

  const filteredSuppliers = suppliers.filter(sup => {
    const q = supplierSearch.toLowerCase();
    return (
      sup.name.toLowerCase().includes(q) ||
      sup.location.toLowerCase().includes(q) ||
      sup.supplyCapacity.toLowerCase().includes(q)
    );
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authForm.email || !authForm.password) {
      setSystemAlert({ message: "Please provide both email and password credentials.", type: "error" });
      setTimeout(() => setSystemAlert({ message: "", type: null }), 3000);
      return;
    }

    setIsAuthLoading(true);
    setTimeout(() => {
      const usersRaw = localStorage.getItem("exo_registered_users");
      let users = [];
      if (usersRaw) {
        try {
          users = JSON.parse(usersRaw);
        } catch (err) {}
      }

      const found = users.find((u: any) => u.email.toLowerCase() === authForm.email.toLowerCase() && u.password === authForm.password);

      if (found) {
        const sessionUser = {
          name: found.name,
          email: found.email,
          businessName: found.businessName,
        };
        localStorage.setItem("exo_session_user", JSON.stringify(sessionUser));
        setCurrentUser(sessionUser);
        setSystemAlert({ message: `Welcome Back, ${found.name}!`, type: "success" });
      } else if (
        authForm.email.toLowerCase() === "praisilia.anastasya@gmail.com" || 
        authForm.email.toLowerCase() === "demo@exopilot.co"
      ) {
        const sessionUser = {
          name: "Praisilia Anastasya",
          email: authForm.email.toLowerCase(),
          businessName: "CV Exporter Assistant",
        };
        localStorage.setItem("exo_session_user", JSON.stringify(sessionUser));
        setCurrentUser(sessionUser);
        setSystemAlert({ message: "Authenticated using Professional Demo Session", type: "success" });
      } else {
        setSystemAlert({ message: "Invalid credentials. Try demo@exopilot.co or register a new one!", type: "error" });
      }

      setIsAuthLoading(false);
      setTimeout(() => setSystemAlert({ message: "", type: null }), 3000);
    }, 1000);
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authForm.name || !authForm.email || !authForm.password || !authForm.businessName) {
      setSystemAlert({ message: "Please complete all fields to establish co-op registration.", type: "error" });
      setTimeout(() => setSystemAlert({ message: "", type: null }), 3000);
      return;
    }

    setIsAuthLoading(true);
    setTimeout(() => {
      const usersRaw = localStorage.getItem("exo_registered_users");
      let users = [];
      if (usersRaw) {
        try {
          users = JSON.parse(usersRaw);
        } catch (err) {}
      }

      const duplicate = users.some((u: any) => u.email.toLowerCase() === authForm.email.toLowerCase());
      if (duplicate) {
        setSystemAlert({ message: "This email address is already registered.", type: "error" });
        setIsAuthLoading(false);
        setTimeout(() => setSystemAlert({ message: "", type: null }), 3000);
        return;
      }

      const newUser = {
        name: authForm.name,
        email: authForm.email,
        password: authForm.password,
        businessName: authForm.businessName,
        specialization: authForm.specialization,
      };

      users.push(newUser);
      localStorage.setItem("exo_registered_users", JSON.stringify(users));

      const sessionUser = {
        name: newUser.name,
        email: newUser.email,
        businessName: newUser.businessName,
      };
      localStorage.setItem("exo_session_user", JSON.stringify(sessionUser));
      setCurrentUser(sessionUser);

      setSystemAlert({ message: `Co-operative registration complete! Welcome aboard, ${newUser.name}.`, type: "success" });
      setIsAuthLoading(false);
      setTimeout(() => setSystemAlert({ message: "", type: null }), 3000);
    }, 1200);
  };

  const handleDemoLogin = () => {
    setIsAuthLoading(true);
    setTimeout(() => {
      const sessionUser = {
        name: "Praisilia Anastasya",
        email: "praisilia.anastasya@gmail.com",
        businessName: "CV Exporter Assistant",
      };
      localStorage.setItem("exo_session_user", JSON.stringify(sessionUser));
      setCurrentUser(sessionUser);
      setSystemAlert({ message: "Quick entry authorized as Praisilia Anastasya!", type: "success" });
      setIsAuthLoading(false);
      setTimeout(() => setSystemAlert({ message: "", type: null }), 3000);
    }, 500);
  };

  const handleLogout = () => {
    localStorage.setItem("exo_session_user", "explicit_logout");
    setCurrentUser(null);
    setSystemAlert({ message: "Logged out. Secure session terminated.", type: "success" });
    setShowProfileDropdown(false);
    setTimeout(() => setSystemAlert({ message: "", type: null }), 3000);
  };

  return (
    <div className="min-h-screen bg-[#F4F6FA] flex flex-col font-sans antialiased">
      {/* ---------------------------------------------------------
          TOP NOTIFICATION SYSTEM FEEDBACKS (AUTO FADES)
         --------------------------------------------------------- */}
      {systemAlert.message && (
        <div className="fixed top-5 right-5 z-50 animate-fade-in shadow-2xl rounded-2xl flex items-center gap-3 px-5 py-4 border bg-white border-l-4 max-w-sm">
          {systemAlert.type === "success" ? (
            <>
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
              <div>
                <p className="text-xs font-bold text-gray-900">Operation Success</p>
                <p className="text-[11px] text-gray-500 font-medium mt-0.5">{systemAlert.message}</p>
              </div>
            </>
          ) : (
            <>
              <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
              <div>
                <p className="text-xs font-bold text-gray-900 font-display">System Notice</p>
                <p className="text-[11px] text-gray-500 font-medium mt-0.5">{systemAlert.message}</p>
              </div>
            </>
          )}
        </div>
      )}

      {/* ---------------------------------------------------------
          NEUTRAL HIGH-CONTRAST SKELETON HEADER
         --------------------------------------------------------- */}
      <header className="bg-white text-slate-900 border-b border-slate-200 px-6 md:px-8 py-3 flex items-center justify-between relative z-30 shadow-[0_1px_3px_rgba(0,0,0,0.02)]">
        
        <div className="flex items-center gap-4 relative z-10">
          <div className="bg-indigo-50 p-2 rounded-xl border border-indigo-100 flex items-center justify-center">
            <Ship className="w-5 h-5 text-indigo-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black tracking-widest text-indigo-600 uppercase">
                Prototype Gateway
              </span>
              <span className="bg-emerald-50 text-emerald-700 text-[9px] font-black px-1.5 py-0.5 rounded border border-emerald-200">
                ACTIVE
              </span>
            </div>
            <h1 className="text-base font-black tracking-tight font-display text-slate-900 leading-tight">
              EXOPILOT <span className="text-indigo-600 font-medium text-xs">Exporter Assistant</span>
            </h1>
          </div>
        </div>

        {/* Dynamic Mode Switcher (Tab Selection) */}
        <div className="flex bg-slate-50 p-1 rounded-2xl border border-slate-200 relative z-10">
          <button
            onClick={() => setActiveSection("live-app")}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-extrabold tracking-wide transition-all ${
              activeSection === "live-app"
                ? "bg-indigo-600 text-white shadow-sm"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Live App Showcase
          </button>
          <button
            onClick={() => setActiveSection("blueprints")}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-extrabold tracking-wide transition-all ${
              activeSection === "blueprints"
                ? "bg-indigo-600 text-white shadow-sm"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            Boilerplate Files
          </button>
        </div>

        {/* Verified User Label with dropdown action */}
        {currentUser ? (
          <div className="relative z-20">
            <button
              onClick={() => setShowProfileDropdown(!showProfileDropdown)}
              className="flex items-center gap-2.5 relative bg-slate-50 hover:bg-slate-100 py-1.5 px-3 rounded-xl border border-slate-200 transition-all text-left focus:outline-none cursor-pointer"
            >
              <div className="w-6.5 h-6.5 rounded-full bg-gradient-to-br from-indigo-500 to-indigo-750 font-black text-[9px] text-white flex items-center justify-center">
                {currentUser.name ? currentUser.name.split(" ").map((w: string) => w[0]).join("").toUpperCase().slice(0, 2) : "EX"}
              </div>
              <div className="text-left leading-none">
                <span className="text-[10px] font-black text-slate-900 tracking-wide block">{currentUser.name}</span>
                <span className="text-[8px] text-indigo-600 font-extrabold block uppercase tracking-widest mt-0.5">{currentUser.businessName || "CV Exporter Assistant"}</span>
              </div>
              <ChevronDown className={`w-3 h-3 text-slate-500 transition-transform duration-200 ${showProfileDropdown ? 'rotate-180' : ''}`} />
            </button>

            {showProfileDropdown && (
              <div className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-2xl shadow-xl p-4 text-slate-800 z-50 animate-fade-in">
                <div className="flex items-center gap-3 border-b border-slate-100 pb-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-pink-500 font-black text-xs text-white flex items-center justify-center">
                    {currentUser.name ? currentUser.name.split(" ").map((w: string) => w[0]).join("").toUpperCase().slice(0, 2) : "EX"}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-950 leading-tight">{currentUser.name}</h4>
                    <span className="text-[10px] text-slate-500 block break-all leading-tight mt-0.5">{currentUser.email}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Business Entity</div>
                  <div className="text-xs font-semibold text-indigo-700 bg-indigo-50/50 p-2 rounded-xl border border-indigo-100/30 mb-2 leading-snug">
                    {currentUser.businessName}
                  </div>
                </div>

                <button
                  onClick={handleLogout}
                  className="w-full flex items-center justify-between mt-3 px-3 py-2 text-xs font-bold tracking-wide text-rose-600 hover:text-white hover:bg-rose-600 active:bg-rose-700 rounded-xl transition-all border border-rose-200 cursor-pointer text-left"
                >
                  <span>Sign Out Session</span>
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="hidden lg:flex items-center gap-2 relative z-10 bg-indigo-50 text-indigo-700 py-1.5 px-3 rounded-xl border border-indigo-150 font-bold text-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
            Guest Mode (Demo)
          </div>
        )}
      </header>

      {/* ---------------------------------------------------------
          MAIN SECTION ROUTER (LIVE APP OR DEVELOPER CODES)
         --------------------------------------------------------- */}
      <div className="flex-1 flex max-h-[calc(100vh-68px)] overflow-hidden">
        
        {/* =========================================================
            VIEW 1: LIVE INTERACTIVE APP SHOWCASE
           ========================================================= */}
        {activeSection === "live-app" ? (
          !currentUser ? (
            <div className="flex-1 overflow-y-auto bg-[#0F172A] text-white flex flex-col justify-center items-center px-4 py-12 relative">
              {/* Stars/Grid aesthetic backdrops */}
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-30 select-none pointer-events-none" />
              
              <div className="absolute top-10 left-10 hidden xl:flex items-center gap-2 text-slate-500 text-xs">
                <Terminal className="w-4 h-4 text-indigo-400" />
                <span>EXOPILOT_SECURITY_DAEMON: v1.0.8 // SESSION_STANDBY_MODE</span>
              </div>

              {/* Centered Login / Sign Up Core Container Card */}
              <div className="w-full max-w-md bg-slate-900/80 border border-slate-800 p-8 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] backdrop-blur-xl relative z-10 text-left">
                {/* Visual Icon Header */}
                <div className="text-center mb-8">
                  <div className="inline-block bg-indigo-600/10 p-4 rounded-3xl border border-indigo-500/20 shadow-inner mb-4 relative group">
                    <div className="absolute inset-0 bg-indigo-500/20 rounded-3xl blur opacity-30 group-hover:opacity-55 transition-opacity pointer-events-none" />
                    <Ship className="w-10 h-10 text-indigo-400 relative z-10" />
                  </div>
                  <h2 className="text-2xl font-black tracking-tight font-display bg-gradient-to-r from-white via-indigo-200 to-indigo-300 bg-clip-text text-transparent">
                    Exopilot Logistics Co-Op
                  </h2>
                  <p className="text-xs text-slate-400 mt-2 font-medium">Ocean Cargo & Spice Pipeline Control Pipeline</p>
                </div>

                {/* Tab Switcher */}
                <div className="grid grid-cols-2 bg-slate-950/60 p-1.5 rounded-2xl border border-slate-800/80 shadow-inner mb-6">
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode("login");
                      setAuthForm({ ...authForm, name: "", businessName: "" });
                    }}
                    className={`py-2 px-4 rounded-xl text-xs font-bold transition-all text-center focus:outline-none cursor-pointer ${
                      authMode === "login"
                        ? "bg-indigo-600 text-white shadow-lg"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    Portal Login
                  </button>
                  <button
                    type="button"
                    onClick={() => setAuthMode("signup")}
                    className={`py-2 px-4 rounded-xl text-xs font-bold transition-all text-center focus:outline-none cursor-pointer ${
                      authMode === "signup"
                        ? "bg-indigo-600 text-white shadow-lg"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    Register Co-Op
                  </button>
                </div>

                {/* Form component */}
                <form onSubmit={authMode === "login" ? handleLogin : handleSignup} className="space-y-4">
                  
                  {authMode === "signup" && (
                    <>
                      {/* Name field */}
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Full Registrant Name</label>
                        <div className="relative">
                          <User className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                          <input
                            type="text"
                            required
                            placeholder="e.g. Praisilia Anastasya"
                            className="w-full bg-slate-950/50 border border-slate-800 hover:border-slate-700 focus:border-indigo-500 rounded-xl py-2.5 pl-10 pr-4 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500/20 text-white placeholder-slate-500 transition-all font-sans"
                            value={authForm.name}
                            onChange={(e) => setAuthForm({ ...authForm, name: e.target.value })}
                          />
                        </div>
                      </div>

                      {/* Business Entity field */}
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Registered Business Entity</label>
                        <div className="relative">
                          <Building className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                          <input
                            type="text"
                            required
                            placeholder="e.g. CV Exporter Assistant, Maluku"
                            className="w-full bg-slate-950/50 border border-slate-800 hover:border-slate-700 focus:border-indigo-500 rounded-xl py-2.5 pl-10 pr-4 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500/20 text-white placeholder-slate-500 transition-all font-sans"
                            value={authForm.businessName}
                            onChange={(e) => setAuthForm({ ...authForm, businessName: e.target.value })}
                          />
                        </div>
                      </div>
                    </>
                  )}

                  {/* Email address */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Co-op Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                      <input
                        type="email"
                        required
                        placeholder="e.g. demo@exopilot.co"
                        className="w-full bg-slate-950/50 border border-slate-800 hover:border-slate-700 focus:border-indigo-500 rounded-xl py-2.5 pl-10 pr-4 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500/20 text-white placeholder-slate-500 transition-all font-sans"
                        value={authForm.email}
                        onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })}
                      />
                    </div>
                  </div>

                  {/* Password block */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Portal Password</label>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                      <input
                        type={showPassword ? "text" : "password"}
                        required
                        placeholder="••••••••••••"
                        className="w-full bg-slate-950/50 border border-slate-800 hover:border-slate-700 focus:border-indigo-500 rounded-xl py-2.5 pl-10 pr-11 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500/20 text-white placeholder-slate-500 transition-all font-sans"
                        value={authForm.password}
                        onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-2.5 p-1 rounded-md text-slate-400 hover:text-white transition-colors cursor-pointer"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {authMode === "signup" && (
                    /* Niche niche selection */
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Specialist Spice Niche</label>
                      <div className="relative">
                        <Compass className="absolute left-3.5 top-3 w-4.5 h-4.5 text-slate-500" />
                        <select
                          className="w-full bg-slate-950/50 border border-slate-800 hover:border-slate-700 focus:border-indigo-500 rounded-xl py-2.5 pl-10 pr-10 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500/20 text-white transition-all appearance-none cursor-pointer font-sans"
                          value={authForm.specialization}
                          onChange={(e) => setAuthForm({ ...authForm, specialization: e.target.value })}
                        >
                          <option value="Cloves & Nutmeg">Cloves & Nutmeg Premium Group</option>
                          <option value="Cassia Cinnamon">Cassia Split & Cinnamon Co-operative</option>
                          <option value="Whole Mace">Whole Mace Specialist Niche</option>
                          <option value="Agricultural Cargo">General Agricultural Cargo Sprawls</option>
                        </select>
                        <ChevronDown className="absolute right-3.5 top-3 w-4 h-4 text-slate-500 pointer-events-none" />
                      </div>
                    </div>
                  )}

                  {/* Primary Submit action */}
                  <button
                    type="submit"
                    disabled={isAuthLoading}
                    className="w-full relative overflow-hidden bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 active:from-indigo-700 text-white py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/15 cursor-pointer mt-6 transition-all duration-300 disabled:opacity-50"
                  >
                    {isAuthLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin text-white" />
                        <span>Verifying Security Matrix...</span>
                      </>
                    ) : (
                      <>
                        <span>{authMode === "login" ? "Authorize Entry" : "Establish Cargo Record"}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </form>

                {/* Instant trial login link */}
                <div className="mt-6 border-t border-slate-800/80 pt-4 flex flex-col items-center gap-1">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">Evaluation shortcuts</span>
                  <button
                    type="button"
                    onClick={handleDemoLogin}
                    disabled={isAuthLoading}
                    className="text-xs text-indigo-400 hover:text-indigo-300 active:text-indigo-200 font-bold transition-colors cursor-pointer p-1"
                  >
                    ⚡ Instant Bypass: Log in as Praisilia (CV Assistant)
                  </button>
                </div>
              </div>

              {/* Subtitle credentials guidelines footer */}
              <div className="absolute bottom-6 flex gap-6 text-[10px] text-slate-500/80 font-bold tracking-wider pointer-events-none select-none">
                <span>SYSTEM_CIPHER DES3-MD5</span>
                <span>•</span>
                <span>SECURE B2B SSL BACKED</span>
                <span>•</span>
                <span>PT REMPAH NUSANTARA ABADI</span>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex overflow-hidden">
            
            {/* IN-APP MENU SIDEBAR */}
            <aside className="w-64 bg-white border-r border-slate-150 flex flex-col justify-between shrink-0">
              <div className="p-4 space-y-6">
                <div>
                  <span className="text-[10px] font-black tracking-widest text-slate-400 uppercase px-3 block">
                    B2B Export Ops
                  </span>
                  <nav className="mt-2.5 space-y-1">
                    {[
                      { id: "dashboard", label: "Dashboard Hub", icon: LayoutDashboard },
                      { id: "inquiries", label: "Buyer Inquiries", icon: ClipboardList, count: inquiries.length },
                      { id: "suppliers", label: "Spice Suppliers", icon: Users, count: suppliers.length },
                      { id: "shipments", label: "Sea Cargo Tracker", icon: Ship, count: shipments.length },
                      { id: "doc-generator", label: "AI Quotation Studio", icon: FileText, hasGlow: true },
                      { id: "settings", label: "User Settings", icon: Settings },
                    ].map((tabItem) => {
                      const IconComp = tabItem.icon;
                      const isCurrent = activeAppTab === tabItem.id;
                      return (
                        <button
                          key={tabItem.id}
                          onClick={() => setActiveAppTab(tabItem.id as any)}
                          className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl transition-all font-semibold text-xs ${
                            isCurrent
                              ? "bg-[#E6F0FA] text-[#2B6CB0] shadow-sm"
                              : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <IconComp className={`w-4 h-4 ${isCurrent ? "text-[#2B6CB0]" : "text-slate-400"}`} />
                            <span>{tabItem.label}</span>
                          </div>
                          {tabItem.count !== undefined && (
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-black ${
                              isCurrent ? "bg-[#2B6CB0]/15 text-[#2B6CB0]" : "bg-slate-100 text-slate-500"
                            }`}>
                              {tabItem.count}
                            </span>
                          )}
                          {tabItem.hasGlow && (
                            <span className="bg-gradient-to-tr from-rose-500 to-indigo-600 text-white text-[8px] font-extrabold px-1.5 py-0.5 rounded tracking-wide uppercase animate-pulse">
                              AI
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </nav>
                </div>

                <div className="pt-2 border-t border-slate-100">
                  <span className="text-[10px] font-black tracking-widest text-slate-400 uppercase px-3 block">
                    Source Network
                  </span>
                  <div className="mt-3 px-3 py-2 bg-emerald-50/50 rounded-xl border border-emerald-100 flex items-center gap-3">
                    <div className="p-1.5 bg-emerald-100 rounded-lg text-emerald-700">
                      <Compass className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[11px] font-bold text-gray-900 leading-tight">East Indonesia</p>
                      <p className="text-[9px] text-emerald-700 font-extrabold mt-0.5">8 Farmer Co-ops active</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* SME Profile Badge */}
              <div className="p-4 m-4 rounded-xl bg-slate-950 text-white relative overflow-hidden shadow-lg border border-slate-800">
                <div className="absolute right-[-15px] bottom-[-15px] opacity-10">
                  <Globe className="w-20 h-20" />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-[8px] tracking-widest font-black uppercase text-slate-400">
                    SME PROTOTYPE CONTEXT
                  </span>
                </div>
                <h4 className="text-xs font-black tracking-tight text-white mt-1.5">Exopilot Active Session</h4>
                <p className="text-[9px] text-indigo-200 mt-1">Replacing Manual Excel / WhatsApp Workflows</p>
              </div>
            </aside>

            {/* LIVE MODULE PANEL CONTENT */}
            <main className="flex-1 bg-[#F4F6FA] p-6 lg:p-8 overflow-y-auto">
              {isPageLoading ? (
                <div className="flex flex-col items-center justify-center py-24 space-y-4">
                  <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
                  <p className="text-xs font-semibold text-slate-400 font-display uppercase tracking-widest">
                    Loading Indonesian Maritime Logistics...
                  </p>
                </div>
              ) : (
                <div className="space-y-6 max-w-6xl">
                  
                  {/* API KEY CHECK BANNER */}
                  {!process.env.GEMINI_API_KEY && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4 flex items-start gap-3.5 shadow-sm">
                      <AlertCircle className="w-5 h-5 text-yellow-600 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-xs font-extrabold text-yellow-800">No GEMINI_API_KEY Configured inside Secrets Panel</h4>
                        <p className="text-[11px] text-yellow-700 mt-0.5 leading-snug">
                          Exopilot built a high-fidelity local template fallback engine for the **AI Quotation Studio**. 
                          You can still fully click, generate, and explore documents! Paste your real key in Settings to watch our tailored spice model live-generate layouts.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* ---------------------------------------------------------
                      TAB C1: DASHBOARD HUB
                     --------------------------------------------------------- */}
                  {activeAppTab === "dashboard" && (
                    <div className="space-y-6 animate-fade-in">
                      
                      {/* Top Welcome Title & Register Action */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div>
                          <h2 className="text-2xl font-black text-slate-900 tracking-tight font-display">
                            Vessel Logistics & Pipeline Control
                          </h2>
                          <p className="text-xs text-slate-500 font-medium">
                            Operational checkpoint of spice batches, global inquiries and direct quotation margins.
                          </p>
                        </div>
                        <button
                          onClick={() => setShowAddModal(true)}
                          className="bg-indigo-600 hover:bg-indigo-700 font-extrabold text-white px-4 py-2.5 rounded-xl text-xs shadow-md shadow-indigo-150 transition-all flex items-center gap-2 cursor-pointer self-start sm:self-center"
                        >
                          <Plus className="w-4 h-4" />
                          Log Buyer Inquiry
                        </button>
                      </div>

                      {/* Operational Quick Utilities Bar */}
                      <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 shadow-xl mt-1 relative overflow-hidden group">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none group-hover:bg-indigo-500/15 transition-all duration-300" />
                        <div className="flex items-center gap-3.5 relative z-10 w-full md:w-auto">
                          <div className="bg-white/10 p-2.5 rounded-xl border border-white/10 shrink-0">
                            <Sparkles className="w-4 h-4 text-indigo-300 animate-pulse" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] uppercase tracking-widest font-black text-indigo-300">Fast Export Helpers</span>
                              <span className="bg-indigo-500/20 text-indigo-300 text-[8px] font-black px-1.5 py-0.5 rounded uppercase border border-indigo-500/20">SME Assist</span>
                            </div>
                            <span className="text-xs font-bold text-slate-300 block mt-0.5">Quickly calculate 20ft/40ft ocean container stuffing capacities and run instant currency translations.</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2.5 w-full md:w-auto shrink-0 relative z-10">
                          <button
                            id="btn-container-calculator"
                            onClick={() => setShowCalcModal(true)}
                            className="flex-1 md:flex-none justify-center bg-indigo-600 hover:bg-indigo-700 active:scale-[98%] text-white font-extrabold px-4 py-2.5 rounded-xl text-xs tracking-wide transition-all shadow-md flex items-center gap-2 cursor-pointer"
                          >
                            <Scale className="w-4 h-4 text-indigo-200" />
                            Container Calculator
                          </button>
                          <button
                            id="btn-currency-converter"
                            onClick={() => setShowConverterModal(true)}
                            className="flex-1 md:flex-none justify-center bg-slate-800 hover:bg-slate-750 active:scale-[98%] text-slate-200 hover:text-white border border-slate-700 font-extrabold px-4 py-2.5 rounded-xl text-xs tracking-wide transition-all flex items-center gap-2 cursor-pointer"
                          >
                            <Coins className="w-4 h-4 text-indigo-300" />
                            Currency Converter
                          </button>
                        </div>
                      </div>

                      {/* STATS BENTO ROW */}
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
                        
                        <div className="bg-white p-5 rounded-3xl border border-slate-100/50 shadow-[0_8px_30px_rgb(0,0,0,0.04)] relative overflow-hidden group hover:shadow-md hover:scale-[101%] transition-all duration-300">
                          <div className="absolute right-0 top-0 bg-yellow-50/50 p-5 rounded-bl-3xl group-hover:scale-110 transition-transform">
                            <ClipboardList className="w-5 h-5 text-yellow-600" />
                          </div>
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                            Total Inquiries
                          </span>
                          <p className="text-2xl font-black text-slate-900 mt-2 font-display">{summary.totalInquiries}</p>
                          <div className="flex items-center gap-1.5 mt-3 text-emerald-600 font-extrabold text-[11px]">
                            <TrendingUp className="w-3.5 h-3.5" />
                            <span>{summary.monthlyIncreaseRate} this month</span>
                          </div>
                        </div>

                        <div className="bg-white p-5 rounded-3xl border border-slate-100/50 shadow-[0_8px_30px_rgb(0,0,0,0.04)] relative overflow-hidden group hover:shadow-md hover:scale-[101%] transition-all duration-300">
                          <div className="absolute right-0 top-0 bg-pink-50/55 p-5 rounded-bl-3xl group-hover:scale-110 transition-transform">
                            <Ship className="w-5 h-5 text-pink-600" />
                          </div>
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                            Cargo In Transit
                          </span>
                          <p className="text-2xl font-black text-slate-900 mt-2 font-display">
                            {shipments.filter(s => s.status !== "Arrived").length}
                          </p>
                          <p className="text-[10px] text-slate-500 font-semibold mt-3.5 flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-indigo-500" /> 
                            Sea Waybills Registered
                          </p>
                        </div>

                        <div className="bg-white p-5 rounded-3xl border border-slate-100/50 shadow-[0_8px_30px_rgb(0,0,0,0.04)] relative overflow-hidden group hover:shadow-md hover:scale-[101%] transition-all duration-300">
                          <div className="absolute right-0 top-0 bg-emerald-50/50 p-5 rounded-bl-3xl group-hover:scale-110 transition-transform">
                            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                          </div>
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                            Closed Deals
                          </span>
                          <p className="text-2xl font-black text-slate-900 mt-2 font-display">{summary.closedDeals}</p>
                          <p className="text-[10px] text-emerald-700 font-bold tracking-wider mt-3.5 uppercase bg-emerald-50 w-fit px-2 py-0.5 rounded">
                            COMPLETED CONTRACTS
                          </p>
                        </div>

                        <div className="p-5 rounded-3xl relative overflow-hidden group hover:shadow-md hover:scale-[101%] transition-all duration-300 bg-gradient-to-tr from-indigo-900 to-indigo-950 text-white shadow-xl shadow-indigo-950/10">
                          <div className="absolute right-[-10px] top-[-10px] text-indigo-800 opacity-20">
                            <Globe className="w-24 h-24" />
                          </div>
                          <span className="text-[10px] font-black text-indigo-300 uppercase tracking-widest">
                            Est. Pipe Value
                          </span>
                          <p className="text-2xl font-black mt-2 font-display">{summary.pipelineValue}</p>
                          <p className="text-[10px] text-indigo-200 font-bold mt-3.5 uppercase">
                            Indonesian Port Pricing
                          </p>
                        </div>

                      </div>

                      {/* GRID PANEL: Active Shipments Status Grid & Recent Inquiry overview */}
                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                        
                        {/* LEFT: SEA HARBOR TRAFFIC CARGO (8 Cols) */}
                        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-150 overflow-hidden shadow-sm">
                          <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                            <div>
                              <h3 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                                Marine Port Container Shipments
                              </h3>
                              <p className="text-[11px] text-slate-400 mt-0.5">Maritime bill of ladings from major ocean loops (Jakarta/Surabaya)</p>
                            </div>
                            <span className="bg-indigo-50 text-indigo-700 text-[9px] font-black px-2 py-0.5 rounded border border-indigo-200">
                              SEA TRACKER
                            </span>
                          </div>

                          <div className="divide-y divide-slate-100">
                            {shipments.map(s => (
                              <div key={s.id} className="p-4 hover:bg-slate-50/50 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                                <div className="space-y-1">
                                  <div className="flex items-center gap-2">
                                    <span className="font-bold text-slate-900 font-mono tracking-tight">{s.containerNumber}</span>
                                    <span className="bg-slate-100 text-slate-600 text-[10px] font-bold px-2 py-0.5 rounded">
                                      {s.shippingLine}
                                    </span>
                                  </div>
                                  <p className="text-slate-500 font-medium">Commodity: <strong className="text-indigo-950 font-semibold">{s.commodity}</strong></p>
                                </div>

                                <div className="flex items-center gap-6">
                                  {/* Shipment Progress layout */}
                                  <div className="space-y-1">
                                    <div className="flex items-center gap-1">
                                      <span className="text-[10px] text-slate-400 font-semibold text-right block">ETD: {s.etd}</span>
                                      <span className="text-slate-300">→</span>
                                      <span className="text-[10px] text-indigo-650 font-bold block">ETA: {s.eta}</span>
                                    </div>
                                    
                                    {/* Visual Track bar */}
                                    <div className="w-40 h-1.5 bg-slate-100 rounded-full overflow-hidden relative">
                                      <div className={`h-full rounded-full ${
                                        s.status === "Arrived" ? "w-full bg-emerald-500" :
                                        s.status === "On Vessel" ? "w-2/3 bg-indigo-500" : "w-1/3 bg-amber-500"
                                      }`} />
                                    </div>
                                  </div>

                                  <span className={`text-[10px] font-extrabold px-3 py-1 rounded-full uppercase border ${
                                    s.status === "Arrived" 
                                      ? "bg-[#E2F7ED] text-[#13804E] border-[#E2F7ED]" 
                                      : s.status === "On Vessel" 
                                      ? "bg-[#EFF6FF] text-[#1D4ED8] border-[#EFF6FF]" 
                                      : "bg-[#FFF1E6] text-[#D97706] border-[#FFF1E6]"
                                  }`}>
                                    {s.status}
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* RIGHT: LIVE EXPORTS PRODUCT CAPABILITIES (4 Cols) */}
                        <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-150 p-5 space-y-4 shadow-sm">
                          <div>
                            <h3 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                              Spice Quality Targets
                            </h3>
                            <p className="text-[11px] text-slate-400 mt-0.5">Exporter Assistant standards</p>
                          </div>

                          <div className="space-y-3.5">
                            <div className="p-3 bg-indigo-50/40 rounded-xl border border-slate-100">
                              <div className="flex justify-between items-center">
                                <span className="font-bold text-slate-900 text-xs">Nutmeg (ABCD Grade)</span>
                                <span className="text-[10px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded font-black font-mono">Premium</span>
                              </div>
                              <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                                Air dried Maluku origin. Moisture level &lt; 10%. Perfect whole pods.
                              </p>
                            </div>

                            <div className="p-3 bg-pink-50/10 rounded-xl border border-slate-100">
                              <div className="flex justify-between items-center">
                                <span className="font-bold text-slate-900 text-xs">Cloves (Lal Pari)</span>
                                <span className="text-[10px] bg-pink-100 text-pink-700 px-2 py-0.5 rounded font-black font-mono">Hand Pick</span>
                              </div>
                              <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                                North Sulawesi red hue cloves. Foreign admixtures &lt; 1.2%. Head intact.
                              </p>
                            </div>

                            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                              <div className="flex justify-between items-center">
                                <span className="font-bold text-slate-900 text-xs">Whole Mace (Pala)</span>
                                <span className="text-[10px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded font-black font-mono">Standard</span>
                              </div>
                              <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                                Full unbroken mace webs. Bright orange to dark vermilion spice oil.
                              </p>
                            </div>
                          </div>
                        </div>

                      </div>

                    </div>
                  )}

                  {/* ---------------------------------------------------------
                      TAB C2: BUYER INQUIRIES REGISTER
                     --------------------------------------------------------- */}
                  {activeAppTab === "inquiries" && (
                    <div className="space-y-6 animate-fade-in">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div>
                          <h2 className="text-xl font-black text-slate-900 tracking-tight font-display">
                            Recent Cargo Buyer Inquiries
                          </h2>
                          <p className="text-xs text-slate-500">
                            Active purchasing requests registered directly into our pipeline databases.
                          </p>
                        </div>
                        <button
                          onClick={() => setShowAddModal(true)}
                          className="bg-indigo-600 hover:bg-indigo-700 font-extrabold text-white px-4 py-2.5 rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer self-start sm:self-center"
                        >
                          <PlusCircle className="w-4 h-4" /> Create New Inquiry
                        </button>
                      </div>

                      {/* Search Bar matching design tokens */}
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-100/80 shadow-[0_8px_30px_rgb(0,0,0,0.02)]">
                        <div className="relative w-full sm:w-80">
                          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                          <input
                            type="text"
                            placeholder="Search buyer company, country, product..."
                            className="w-full pl-9 pr-4 py-2 text-xs font-semibold rounded-full bg-slate-100/70 hover:bg-slate-100 focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:outline-none border border-transparent focus:border-slate-200 transition-all text-slate-800 placeholder-slate-400"
                            value={inquirySearch}
                            onChange={(e) => setInquirySearch(e.target.value)}
                          />
                        </div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest self-end sm:self-auto">
                          Showing {filteredInquiries.length} of {inquiries.length} Inquiries
                        </div>
                      </div>

                      {/* INQUIRY CARDS/TABLE LIST WITH LIVE DELETE MUTATION */}
                      <div className="bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
                        <div className="overflow-x-auto">
                          <table className="w-full text-left border-collapse">
                            <thead>
                              <tr className="bg-slate-50/80 border-b border-slate-150 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                                <th className="py-4 px-6">Buyer Company</th>
                                <th className="py-4 px-6">Export Destination</th>
                                <th className="py-4 px-6">Spice Commodity</th>
                                <th className="py-4 px-6">Cargo Quantity</th>
                                <th className="py-4 px-6">Target Offer Rate</th>
                                <th className="py-4 px-6 text-center">Inquiry Status</th>
                                <th className="py-4 px-6 text-center">Action</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 text-xs">
                              {filteredInquiries.map((inq) => (
                                <tr key={inq.id} className="hover:bg-slate-50/50 transition-colors">
                                  <td className="py-4 px-6 md:max-w-xs">
                                    <div className="font-bold text-slate-900 font-display">{inq.buyerName}</div>
                                    <div className="flex flex-col gap-1 mt-0.5">
                                      <span className="text-[10px] text-slate-400 font-mono">ID: {inq.id}</span>
                                      {inq.negotiationNotes && (
                                        <div className="p-2 border border-amber-100 bg-amber-50/50 rounded-lg text-[10px] text-slate-700 font-sans tracking-wide">
                                          <div className="text-[8px] font-black text-amber-800 uppercase tracking-widest leading-none mb-1">Negotiation Notes</div>
                                          {inq.negotiationNotes}
                                        </div>
                                      )}
                                    </div>
                                  </td>
                                  <td className="py-4 px-6 text-slate-600 font-semibold">
                                    <span className="flex items-center gap-1.5">
                                      <Globe className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                                      {inq.country}
                                    </span>
                                  </td>
                                  <td className="py-4 px-6 font-semibold text-slate-700">{inq.product}</td>
                                  <td className="py-4 px-6 font-black text-indigo-750">{inq.quantity}</td>
                                  <td className="py-4 px-6 font-bold text-emerald-800">{inq.price || "Negotiable"}</td>
                                  <td className="py-4 px-6 text-center">
                                    <span className={`inline-block text-[10px] font-black px-3 py-1 rounded-full uppercase border ${
                                      inq.status === "Closed"
                                        ? "bg-[#E2F7ED] text-[#13804E] border-[#E2F7ED]"
                                        : inq.status === "Negotiating"
                                        ? "bg-[#FFF1E6] text-[#D97706] border-[#FFF1E6]"
                                        : "bg-[#EFF6FF] text-[#1D4ED8] border-[#EFF6FF]"
                                    }`}>
                                      {inq.status}
                                    </span>
                                  </td>
                                  <td className="py-4 px-6 text-center">
                                    <div className="flex items-center justify-center gap-2">
                                      <button
                                        onClick={() => {
                                          setActiveAppTab("doc-generator");
                                          setSelectedInquiryId(inq.id);
                                        }}
                                        title="Generate Quotation using AI Model"
                                        className="p-1.5 hover:bg-indigo-50 text-indigo-600 rounded-lg transition-colors cursor-pointer"
                                      >
                                        <Sparkles className="w-4 h-4" />
                                      </button>
                                      <button
                                        onClick={() => deleteInquiry(inq.id)}
                                        title="Purge record"
                                        className="p-1.5 hover:bg-rose-50 text-rose-600 rounded-lg transition-colors cursor-pointer"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>

                        {inquiries.length === 0 && (
                          <div className="p-12 text-center text-slate-400 font-medium text-xs">
                            No inquiries currently logged inside memory databases. Tap &apos;Create Inquiry&apos; above.
                          </div>
                        )}
                      </div>

                    </div>
                  )}

                  {/* ---------------------------------------------------------
                      TAB C2.5: SPICE SUPPLIERS MANAGER
                     --------------------------------------------------------- */}
                  {activeAppTab === "suppliers" && (
                    <div className="space-y-6 animate-fade-in">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div>
                          <h2 className="text-xl font-black text-slate-900 tracking-tight font-display">
                            Sourcing Suppliers & Farmers Cooperatives
                          </h2>
                          <p className="text-xs text-slate-500">
                            Local Indonesian spice farmers and regional cooperatives integrated into our pipeline.
                          </p>
                        </div>
                        <button
                          onClick={() => setShowAddSupplierModal(true)}
                          className="bg-indigo-600 hover:bg-indigo-700 font-extrabold text-white px-4 py-2.5 rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer self-start sm:self-center font-display"
                        >
                          <PlusCircle className="w-4 h-4" /> Register Supplier Co-Op
                        </button>
                      </div>

                      {/* Search Bar matching design tokens */}
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-100/80 shadow-[0_8px_30px_rgb(0,0,0,0.02)]">
                        <div className="relative w-full sm:w-80">
                          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                          <input
                            type="text"
                            placeholder="Search cooperative, region, capacity..."
                            className="w-full pl-9 pr-4 py-2 text-xs font-semibold rounded-full bg-slate-100/70 hover:bg-slate-100 focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:outline-none border border-transparent focus:border-slate-200 transition-all text-slate-800 placeholder-slate-400"
                            value={supplierSearch}
                            onChange={(e) => setSupplierSearch(e.target.value)}
                          />
                        </div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest self-end sm:self-auto">
                          Showing {filteredSuppliers.length} of {suppliers.length} Cooperatives
                        </div>
                      </div>

                      {/* SUPPLIERS TABLE LIST */}
                      <div className="bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
                        <div className="overflow-x-auto">
                          <table className="w-full text-left border-collapse">
                            <thead>
                              <tr className="bg-slate-50/80 border-b border-slate-150 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                                <th className="py-4 px-6">Cooperative/Supplier Name</th>
                                <th className="py-4 px-6">Sourcing Location</th>
                                <th className="py-4 px-6">Supply Capacity</th>
                                <th className="py-4 px-6 font-mono text-center">Registered On</th>
                                <th className="py-4 px-6 text-center">Action</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 text-xs">
                              {filteredSuppliers.map((sup) => (
                                <tr key={sup.id} className="hover:bg-slate-50/50 transition-colors">
                                  <td className="py-4 px-6">
                                    <div className="flex items-center gap-2 font-bold text-slate-900 font-display">
                                      <Warehouse className="w-4 h-4 text-emerald-600 shrink-0" />
                                      {sup.name}
                                    </div>
                                    <span className="text-[10px] text-slate-400 font-mono block mt-0.5">ID: {sup.id}</span>
                                  </td>
                                  <td className="py-4 px-6 text-slate-600 font-semibold">
                                    <span className="flex items-center gap-1.5">
                                      <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                                      {sup.location}
                                    </span>
                                  </td>
                                  <td className="py-4 px-6">
                                    <span className="inline-block whitespace-nowrap px-2.5 py-1 text-[10px] font-black uppercase bg-indigo-50 text-indigo-700 border border-indigo-100 rounded-full">
                                      {sup.supplyCapacity}
                                    </span>
                                  </td>
                                  <td className="py-4 px-6 text-center text-slate-400 font-mono text-[10px]">
                                    {sup.createdAt}
                                  </td>
                                  <td className="py-4 px-6 text-center">
                                    <button
                                      onClick={() => deleteSupplier(sup.id)}
                                      title="Purge record"
                                      className="p-1.5 hover:bg-rose-50 text-rose-600 rounded-lg transition-colors cursor-pointer"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>

                        {suppliers.length === 0 && (
                          <div className="p-12 text-center text-slate-400 font-medium text-xs">
                            No supplier cooperatives logged or available in this session.
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* ---------------------------------------------------------
                      TAB C3: SEA CARGO CONTAINER TRACKER
                     --------------------------------------------------------- */}
                  {activeAppTab === "shipments" && (
                    <div className="space-y-6 animate-fade-in">
                      <div>
                        <h2 className="text-xl font-black text-slate-900 tracking-tight font-display">
                          Sea Container Transit Logistics
                        </h2>
                        <p className="text-xs text-slate-500">
                          Active cargo tracks originating from Indonesian gateway sea ports to destination harbors.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {shipments.map(sh => (
                          <div key={sh.id} className="bg-white rounded-2xl border border-slate-150 overflow-hidden shadow-sm hover:shadow-md transition-shadow relative">
                            {/* status stripe gradient */}
                            <div className={`h-1.5 w-full ${
                              sh.status === "Arrived" ? "bg-emerald-500" :
                              sh.status === "On Vessel" ? "bg-indigo-500" : "bg-amber-400"
                            }`} />

                            <div className="p-5 space-y-4">
                              <div className="flex justify-between items-start">
                                <div className="space-y-1">
                                  <span className="text-[10px] font-mono font-extrabold tracking-widest text-slate-400 block uppercase">
                                    Ocean Bill of Lading
                                  </span>
                                  <h4 className="text-base font-black text-slate-900 font-mono">{sh.containerNumber}</h4>
                                </div>
                                <span className={`text-[9px] font-black px-2.5 py-1 rounded-full uppercase border ${
                                  sh.status === "Arrived" 
                                    ? "bg-[#E2F7ED] text-[#13804E] border-[#E2F7ED]" 
                                    : sh.status === "On Vessel" 
                                    ? "bg-[#EFF6FF] text-[#1D4ED8] border-[#EFF6FF]" 
                                    : "bg-[#FFF1E6] text-[#D97706] border-[#FFF1E6]"
                                }`}>
                                  {sh.status}
                                </span>
                              </div>

                              <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-100">
                                <div>
                                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest block">Cargo Line</span>
                                  <span className="font-bold text-slate-800">{sh.shippingLine}</span>
                                </div>
                                <div>
                                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest block">Commodity</span>
                                  <span className="font-bold text-slate-800">{sh.commodity}</span>
                                </div>
                              </div>

                              <div className="space-y-2.5">
                                <div className="flex justify-between text-xs font-semibold">
                                  <span className="text-slate-400">Departure (ETD)</span>
                                  <span className="text-slate-800">{sh.etd}</span>
                                </div>
                                <div className="flex justify-between text-xs font-semibold">
                                  <span className="text-indigo-600 block">Arrival (ETA)</span>
                                  <span className="text-indigo-900 font-black">{sh.eta}</span>
                                </div>
                              </div>

                              {/* Progress Track details */}
                              <div className="space-y-1.5 pt-2">
                                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden relative">
                                  <div className={`h-full rounded-full ${
                                    sh.status === "Arrived" ? "w-full bg-emerald-500" :
                                    sh.status === "On Vessel" ? "w-2/3 bg-indigo-500" : "w-1/3 bg-amber-500"
                                  }`} />
                                </div>
                                <div className="flex justify-between text-[9px] font-bold text-slate-400 tracking-wider uppercase">
                                  <span>Ports Clearance</span>
                                  <span>Ocean Transit</span>
                                  <span>Harbor Discharged</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>

                    </div>
                  )}

                  {/* ---------------------------------------------------------
                      TAB C4: AI QUOTATION DOCUMENT GENERATOR CORE
                     --------------------------------------------------------- */}
                  {activeAppTab === "doc-generator" && (
                    <div className="space-y-6 animate-fade-in max-w-5xl">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="bg-gradient-to-tr from-pink-500 to-indigo-600 text-white text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-widest">
                            AI CORE ENGINE
                          </span>
                          <span className="text-xs font-semibold text-indigo-600 tracking-widest uppercase">
                            Gemini-3.5-Flash
                          </span>
                        </div>
                        <h2 className="text-xl font-black text-slate-900 tracking-tight font-display mt-1">
                          AI Export Document Studio
                        </h2>
                        <p className="text-xs text-slate-500">
                          Formulates fully structured Commercial Invoices, Packing Lists, Quotations, PO Drafts, Formal Emails, Shipping Instructions, and Contract Templates. Powered by targeted Indonesian export models.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                        
                        {/* LEFT FORM ENTRANCE CONTROLLER (5 columns) */}
                        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-150 p-5 space-y-4 shadow-sm flex flex-col justify-between">
                          <div className="space-y-4">
                            <span className="text-[10px] font-black text-slate-400 tracking-wider uppercase block">
                              Select Document Parameters
                            </span>

                            {/* Select Document Type */}
                            <div className="space-y-1.5">
                              <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                                <FileText className="w-3 h-3 text-indigo-500" /> Target Document Template
                              </label>
                              <select
                                className="w-full px-3.5 py-2.5 rounded-xl border border-indigo-200 text-xs bg-indigo-50/30 text-indigo-950 font-black focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                                value={customDocForm.docType}
                                onChange={(e) => setCustomDocForm({ ...customDocForm, docType: e.target.value })}
                              >
                                <option value="Quotation">Quotation (Letter of Offer)</option>
                                <option value="Invoice">Invoice (Commercial Invoice)</option>
                                <option value="Packing List">Packing List (Package Breakdown)</option>
                                <option value="Purchase Order Draft">Purchase Order Draft (PO Draft)</option>
                                <option value="Email Formal">Formal Email (B2B Outreach Proposal)</option>
                                <option value="Shipping Instruction">Shipping Instruction (SI Forwarder Note)</option>
                                <option value="Contract Template">Contract Template (International Trade Agreement)</option>
                              </select>
                            </div>

                            {/* Select from existing inquiries */}
                            <div className="space-y-1.5 pt-1">
                              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                                Import Quick-Fill Inquiry Profile
                              </label>
                              <select
                                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                                value={selectedInquiryId}
                                onChange={(e) => setSelectedInquiryId(e.target.value)}
                              >
                                <option value="">--- Create Custom Brand manually ---</option>
                                {inquiries.map(i => (
                                  <option key={i.id} value={i.id}>
                                    {i.buyerName} ({i.product} - {i.quantity})
                                  </option>
                                ))}
                              </select>
                            </div>

                            {/* Manual Custom parameters */}
                            <div className="space-y-3.5 pt-2 border-t border-slate-100">
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                  Buyer Company Name (buyer)
                                </label>
                                <input
                                  type="text"
                                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                  value={customDocForm.buyerName}
                                  onChange={(e) => setCustomDocForm({ ...customDocForm, buyerName: e.target.value })}
                                />
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                  Spice Produce & Target Grade (produk)
                                </label>
                                <input
                                  type="text"
                                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                  value={customDocForm.commodity}
                                  onChange={(e) => setCustomDocForm({ ...customDocForm, commodity: e.target.value })}
                                />
                              </div>

                              <div className="grid grid-cols-2 gap-3">
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                    Weight Volume (quantity)
                                  </label>
                                  <input
                                    type="text"
                                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                    value={customDocForm.quantity}
                                    onChange={(e) => setCustomDocForm({ ...customDocForm, quantity: e.target.value })}
                                  />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                    FOB Rate / Price (harga)
                                  </label>
                                  <input
                                    type="text"
                                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                    value={customDocForm.price}
                                    onChange={(e) => setCustomDocForm({ ...customDocForm, price: e.target.value })}
                                  />
                                </div>
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                  Destination Country (negara tujuan)
                                </label>
                                <input
                                  type="text"
                                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                  value={customDocForm.destinationCountry}
                                  onChange={(e) => setCustomDocForm({ ...customDocForm, destinationCountry: e.target.value })}
                                  placeholder="e.g. Netherlands, Germany, Japan, Turkey"
                                />
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                  Negotiation Notes & Special Demands
                                </label>
                                <textarea
                                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none font-sans"
                                  rows={2}
                                  placeholder="e.g. Requests phytosanitary pre-verification, prompt loading from port."
                                  value={customDocForm.negotiationNotes || ""}
                                  onChange={(e) => setCustomDocForm({ ...customDocForm, negotiationNotes: e.target.value })}
                                />
                              </div>
                            </div>
                          </div>

                          <button
                            onClick={generateExportQuotation}
                            disabled={isGeneratingDoc || !customDocForm.buyerName || !customDocForm.commodity}
                            className="w-full bg-gradient-to-tr from-rose-500 to-indigo-600 hover:from-rose-600 hover:to-indigo-700 font-extrabold text-white text-xs py-3.5 rounded-xl shadow-lg shadow-indigo-100 transition-all flex items-center justify-center gap-2 cursor-pointer mt-4"
                          >
                            {isGeneratingDoc ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin" />
                                Analyzing & compiling {customDocForm.docType}...
                              </>
                            ) : (
                              <>
                                <Sparkles className="w-4 h-4" />
                                Generate Custom {customDocForm.docType}
                              </>
                            )}
                          </button>
                        </div>

                        {/* RIGHT DOCUMENT PREVIEW DISPLAY CANVAS (7 columns) */}
                        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-150 overflow-hidden shadow-sm flex flex-col justify-between">
                          <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between bg-slate-50/50 shrink-0">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-black uppercase text-indigo-950 tracking-wider flex items-center gap-2">
                                <span className={`w-2 h-2 rounded-full ${isGeneratingDoc ? 'bg-indigo-500 animate-ping' : 'bg-emerald-500'}`} />
                                Document Output Studio
                              </span>
                              
                              {generatedDoc && (
                                <div className="flex bg-slate-200/60 p-0.5 rounded-lg border border-slate-300/30 ml-2">
                                  <button
                                    onClick={() => setPreviewTab("pdf")}
                                    className={`px-2.5 py-1 rounded text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                                      previewTab === "pdf"
                                        ? "bg-indigo-600 text-white shadow-sm"
                                        : "text-slate-500 hover:text-slate-800"
                                    }`}
                                  >
                                    PDF Preview
                                  </button>
                                  <button
                                    onClick={() => setPreviewTab("markdown")}
                                    className={`px-2.5 py-1 rounded text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                                      previewTab === "markdown"
                                        ? "bg-indigo-600 text-white shadow-sm"
                                        : "text-slate-500 hover:text-slate-800"
                                    }`}
                                  >
                                    Raw Code
                                  </button>
                                </div>
                              )}
                            </div>
                            {generatedDoc && (
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => handleCopy(generatedDoc, "document")}
                                  className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-indigo-600 bg-white px-2.5 py-1.5 rounded-lg border border-slate-200 cursor-pointer text-[11px]"
                                >
                                  {copiedText === "document" ? (
                                    <>
                                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                                      Copied!
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="w-3.5 h-3.5" />
                                      Copy Code
                                    </>
                                  )}
                                </button>
                                <button
                                  onClick={exportToPDF}
                                  className="flex items-center gap-1.5 text-xs text-white bg-indigo-600 hover:bg-indigo-700 px-3 py-1.5 rounded-lg shadow-sm cursor-pointer text-[11px] font-bold transition-all"
                                >
                                  <FileText className="w-3.5 h-3.5" />
                                  Export to PDF
                                </button>
                              </div>
                            )}
                          </div>

                          {/* Raw Output Terminal or Text Editor preview */}
                          <div className={`p-5 flex-1 overflow-y-auto ${previewTab === "pdf" && generatedDoc ? "min-h-[500px]" : "max-h-[500px]"} font-mono text-xs text-slate-800 bg-[#FAFBFD] space-y-4`}>
                            {isGeneratingDoc ? (
                              <div className="flex flex-col items-center justify-center py-24 space-y-4">
                                <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
                                <div className="text-center space-y-1">
                                  <p className="text-[11px] font-extrabold text-indigo-600">Querying Gemini 3.5-Flash Router...</p>
                                  <p className="text-[10px] text-slate-400">Structuring terms following International Cargo Incoterms 2020</p>
                                </div>
                              </div>
                            ) : generatedDoc ? (
                              previewTab === "pdf" ? (
                                <HighFidelityPaperPreview docText={generatedDoc} docType={customDocForm.docType} />
                              ) : (
                                <div className="space-y-4 leading-relaxed whitespace-pre-wrap font-sans">
                                  {generatedDoc}
                                </div>
                              )
                            ) : (
                              <div className="flex flex-col items-center justify-center py-24 text-center space-y-3.5">
                                <FileText className="w-12 h-12 text-slate-300" />
                                <div className="space-y-1 max-w-xs">
                                  <p className="text-xs font-bold text-gray-900">Quotation Empty</p>
                                  <p className="text-[10px] text-slate-400">Select an active client record on the left or type your customized metrics, then click Generate to query the live export director model.</p>
                                </div>
                              </div>
                            )}
                          </div>

                          {generatedDoc && (
                            <div className="p-3.5 bg-indigo-50 border-t border-slate-100 text-center text-[10px] font-extrabold text-indigo-700 tracking-wider uppercase shrink-0">
                              ✓ Output generated using official @google/genai SDK model interfaces
                            </div>
                          )}
                        </div>

                      </div>

                    </div>
                  )}

                  {/* ---------------------------------------------------------
                      TAB C5: USER SETTINGS PORTAL
                     --------------------------------------------------------- */}
                  {activeAppTab === "settings" && currentUser && (
                    <div className="space-y-6 animate-fade-in max-w-4xl pb-12">
                      <div>
                        <h2 className="text-xl font-black text-slate-900 tracking-tight font-display">
                          User Settings & Business Profile
                        </h2>
                        <p className="text-xs text-slate-500">
                          Manage your Exopilot co-operative session credentials, export business profile, and trade specializations.
                        </p>
                      </div>

                      <div className="bg-white rounded-3xl border border-slate-100 p-6 md:p-8 shadow-[0_8px_30px_rgb(0,0,0,0.03)] space-y-8">
                        {/* Section Headline */}
                        <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
                          <div className="p-2 bg-indigo-50 rounded-xl text-indigo-600">
                            <Settings className="w-5 h-5" />
                          </div>
                          <div>
                            <h3 className="text-sm font-bold text-slate-900 leading-tight">Profile Details</h3>
                            <p className="text-[10px] text-slate-400 font-medium">These details are dynamically injected into your smart trade contracts and PDF export letters.</p>
                          </div>
                        </div>

                        {/* Settings Form Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Full Registrant Name</label>
                            <input
                              type="text"
                              className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 rounded-xl py-2.5 px-3.5 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/10 text-slate-800 transition-all font-sans"
                              value={currentUser.name}
                              onChange={(e) => {
                                const updated = { ...currentUser, name: e.target.value };
                                setCurrentUser(updated);
                                localStorage.setItem("exo_session_user", JSON.stringify(updated));
                              }}
                            />
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Registered Business Entity</label>
                            <input
                              type="text"
                              className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 rounded-xl py-2.5 px-3.5 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/10 text-slate-800 transition-all font-sans"
                              value={currentUser.businessName}
                              onChange={(e) => {
                                const updated = { ...currentUser, businessName: e.target.value };
                                setCurrentUser(updated);
                                localStorage.setItem("exo_session_user", JSON.stringify(updated));
                              }}
                            />
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Co-op Email Address (Read-only)</label>
                            <input
                              type="email"
                              disabled
                              className="w-full bg-slate-100 border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs font-semibold text-slate-400 font-sans cursor-not-allowed"
                              value={currentUser.email}
                            />
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">System Role Designation (Read-only)</label>
                            <input
                              type="text"
                              disabled
                              className="w-full bg-slate-100 border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs font-semibold text-slate-400 font-sans cursor-not-allowed"
                              value="Official Co-op Partner"
                            />
                          </div>
                        </div>

                        {/* Trade Settings Section */}
                        <div className="border-t border-slate-100 pt-6 space-y-4">
                          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Trading Control System Preferences</h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                              <div className="space-y-0.5">
                                <p className="text-xs font-bold text-slate-800">Auto-inject Trade Profile</p>
                                <p className="text-[10px] text-slate-400 leading-normal max-w-xs">Always append your registered business entity to generated AI quotations as standard Exporter.</p>
                              </div>
                              <input
                                type="checkbox"
                                defaultChecked
                                className="w-4.5 h-4.5 text-[#2B6CB0] border-slate-300 rounded focus:ring-indigo-500"
                              />
                            </div>

                            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                              <div className="space-y-0.5">
                                <p className="text-xs font-bold text-slate-800">Encrypted Cloud Ingress</p>
                                <p className="text-[10px] text-slate-400 leading-normal max-w-xs">Enforce strict B2B standard SSL endpoints and secure localStorage caching rules.</p>
                              </div>
                              <input
                                type="checkbox"
                                defaultChecked
                                disabled
                                className="w-4.5 h-4.5 text-[#2B6CB0] border-slate-300 rounded focus:ring-indigo-500 opacity-50 cursor-not-allowed"
                              />
                            </div>
                          </div>
                        </div>

                        {/* Save Confirmation Toast Simulation */}
                        <div className="flex items-center justify-between border-t border-slate-100 pt-6">
                          <p className="text-[11px] text-slate-400 font-medium">Session state automatically synchronizes to client browser localStorage database.</p>
                          <button
                            onClick={() => {
                              setSystemAlert({ message: "Settings profile saved successfully!", type: "success" });
                              setTimeout(() => setSystemAlert({ message: "", type: null }), 3000);
                            }}
                            className="bg-indigo-600 hover:bg-indigo-700 font-extrabold text-white px-5 py-2.5 rounded-xl text-xs shadow-md shadow-indigo-600/10 transition-all flex items-center gap-2 cursor-pointer"
                          >
                            Save Settings Profile
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                </div>
              )}
            </main>

          </div>
          )
        ) : (
          
          /* =========================================================
             VIEW 2: CODE BOILERPLATES INTERACTIVE TERMINAL
             Exhibits beautiful copyable code files requested by user DDL etc.
             ========================================================= */
          <div className="flex-1 flex overflow-hidden">
            
            {/* BOILERPLATE SELECTOR TABS */}
            <aside className="w-72 bg-white border-r border-slate-150 flex flex-col justify-between shrink-0">
              <div className="p-4 space-y-6">
                <div>
                  <span className="text-[10px] font-black tracking-widest text-slate-400 uppercase px-3 block">
                    Export microservices & modules
                  </span>
                  <nav className="mt-2.5 space-y-1.5">
                    {[
                      { id: "sql-schema", label: "Supabase DB DDL Script", file: "supabase-schema.sql", size: "3.1 KB", icon: Database },
                      { id: "go-backend", label: "Go API Handler File", file: "main.go", size: "4.8 KB", icon: Terminal },
                      { id: "nextjs-dashboard", label: "Next.js UI Dashboard Code", file: "dashboard/page.tsx", size: "2.4 KB", icon: Layers },
                      { id: "nextjs-api-route", label: "Gemini Document Route", file: "api/gen-doc/route.ts", size: "1.9 KB", icon: Sparkles },
                    ].map((bt) => {
                      const IconComp = bt.icon;
                      const isSelected = activeBlueprintTab === bt.id;
                      return (
                        <button
                          key={bt.id}
                          onClick={() => setActiveBlueprintTab(bt.id as any)}
                          className={`w-full text-left p-3 rounded-xl transition-all border ${
                            isSelected
                              ? "bg-[#FAF8FE] border-indigo-200 text-indigo-700 shadow-sm"
                              : "border-transparent text-slate-500 hover:bg-slate-50 hover:text-slate-900"
                          }`}
                        >
                          <div className="flex items-start gap-3">
                            <IconComp className={`w-4 h-4 mt-0.5 shrink-0 ${isSelected ? "text-indigo-600" : "text-slate-400"}`} />
                            <div className="space-y-0.5 leading-none">
                              <span className="text-xs font-bold block">{bt.label}</span>
                              <span className="text-[9px] font-mono text-slate-400 block tracking-tight">{bt.file} • {bt.size}</span>
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </nav>
                </div>

                <div className="pt-2 border-t border-slate-100">
                  <span className="text-[10px] font-black tracking-widest text-slate-400 uppercase px-3 block">
                    Developer Architecture Info
                  </span>
                  <p className="text-[11px] text-slate-500 leading-relaxed px-3 mt-2.5">
                    These boilerplates are structured cleanly to map Firebase UIDs to Supabase PostgreSQL foreign keys, enforce RLS policies, and handle Go and Next.js integrations.
                  </p>
                </div>
              </div>

              {/* Instructions on implementation */}
              <div className="p-4 m-4 rounded-xl bg-indigo-50 border border-indigo-100 space-y-2">
                <span className="text-[9px] font-black tracking-widest text-indigo-600 uppercase block">
                  Implementation Note:
                </span>
                <p className="text-[10px] text-slate-600 leading-snug">
                  The active app is tied to a standard robust full-stack container. Copy any workspace code file using the Copy button in the code pane header.
                </p>
              </div>
            </aside>

            {/* HIGH-FIDELITY SYNTAX VIEWPORT CODE PANE */}
            <main className="flex-1 bg-slate-900 text-slate-100 flex flex-col justify-between overflow-hidden relative">
              <div className="p-4 bg-slate-950 flex items-center justify-between border-b border-slate-800 shrink-0">
                <div className="flex items-center gap-3">
                  <div className="flex gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  </div>
                  <span className="text-[10px] font-mono text-slate-400 tracking-wider">
                    {activeBlueprintTab === "sql-schema" ? "blueprints/supabase-schema.sql" :
                     activeBlueprintTab === "go-backend" ? "blueprints/main.go" :
                     activeBlueprintTab === "nextjs-dashboard" ? "blueprints/dashboard-page.tsx" :
                     "blueprints/generate-document-route.ts"}
                  </span>
                </div>

                <button
                  onClick={() => {
                    const codeToCopy = 
                      activeBlueprintTab === "sql-schema" ? sqlSchemaCode :
                      activeBlueprintTab === "go-backend" ? goBackendCode :
                      activeBlueprintTab === "nextjs-dashboard" ? nextjsPageCode :
                      nextjsApiCode;
                    handleCopy(codeToCopy, activeBlueprintTab);
                  }}
                  className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700 cursor-pointer text-[11px]"
                >
                  {copiedText === activeBlueprintTab ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-indigo-400" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Copy Code
                    </>
                  )}
                </button>
              </div>

              {/* Scrollable code layout pre */}
              <div className="flex-1 overflow-y-auto p-6 font-mono text-xs leading-relaxed text-indigo-200">
                <pre className="whitespace-pre">
                  {activeBlueprintTab === "sql-schema" && sqlSchemaCode}
                  {activeBlueprintTab === "go-backend" && goBackendCode}
                  {activeBlueprintTab === "nextjs-dashboard" && nextjsPageCode}
                  {activeBlueprintTab === "nextjs-api-route" && nextjsApiCode}
                </pre>
              </div>

              {/* Console logs visual indicator footer */}
              <div className="p-2.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-[10px] font-mono text-slate-500 px-5 shrink-0">
                <span>Standard compliance: RFC 4627 JSON payload mappings</span>
                <span>UTF-8 encoded</span>
              </div>
            </main>

          </div>
        )}
      </div>

      {/* ---------------------------------------------------------
          INTERACTIVE ACTION MODAL FOR BUYER INQUIRY
         --------------------------------------------------------- */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in text-slate-800">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-slate-150">
            
            <div className="p-5 bg-gradient-to-tr from-slate-900 to-indigo-950 text-white flex justify-between items-center">
              <div>
                <h3 className="font-extrabold text-sm tracking-wide uppercase">
                  Log Spice Inquiry
                </h3>
                <p className="text-[10px] text-indigo-200 mt-0.5 leading-none">Adding entry to Exporter Assistant memory store</p>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-indigo-200 hover:text-white font-black text-xl cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={submitInquiry} className="p-6 space-y-4">
              
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                  Buyer Company Name
                </label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Klausen Spice GmbH"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  value={newInquiryForm.buyerName}
                  onChange={(e) => setNewInquiryForm({ ...newInquiryForm, buyerName: e.target.value })}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                  Export Country Destination
                </label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Germany, Japan, Singapore"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  value={newInquiryForm.country}
                  onChange={(e) => setNewInquiryForm({ ...newInquiryForm, country: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                    Spice Produce Category
                  </label>
                  <select
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    value={newInquiryForm.product}
                    onChange={(e) => setNewInquiryForm({ ...newInquiryForm, product: e.target.value })}
                  >
                    <option value="Nutmeg (ABCD Grade)">Nutmeg pods</option>
                    <option value="Cloves (Lal Pari Grade)">Cloves buds</option>
                    <option value="Mace (Whole Grade)">Mace webs</option>
                    <option value="Split Cassia split">Cinnamon splits</option>
                    <option value="Sumatra Cocoa Bean">Cocoa premium</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                    Cargo Target Volume
                  </label>
                  <input
                    required
                    type="text"
                    placeholder="e.g. 15 MT"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    value={newInquiryForm.quantity}
                    onChange={(e) => setNewInquiryForm({ ...newInquiryForm, quantity: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                  Target Price Rate (FOB, USD/MT)
                </label>
                <input
                  required
                  type="text"
                  placeholder="e.g. $8,500/MT"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  value={newInquiryForm.price}
                  onChange={(e) => setNewInquiryForm({ ...newInquiryForm, price: e.target.value })}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                  Negotiation Notes & Special Buyer Demands
                </label>
                <textarea
                  placeholder="e.g. Requests phytosanitary certificate, negotiable split shipment options."
                  rows={2}
                  className="w-full px-4 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none font-sans"
                  value={newInquiryForm.negotiationNotes}
                  onChange={(e) => setNewInquiryForm({ ...newInquiryForm, negotiationNotes: e.target.value })}
                />
              </div>

              <div className="pt-4 flex gap-3 justify-end">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-500 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingInquiry}
                  className="px-5 py-2.5 rounded-xl bg-indigo-650 hover:bg-indigo-700 text-white font-bold text-xs shadow-md cursor-pointer flex items-center justify-center gap-1"
                >
                  {isSubmittingInquiry ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Save to Pipeline"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------------
          MODAL: REGISTER SPICE SUPPLIER
         --------------------------------------------------------- */}
      {showAddSupplierModal && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in text-slate-800">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-150 animate-scale-up">
            
            <div className="p-5 bg-gradient-to-tr from-emerald-800 to-teal-950 text-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="bg-white/10 p-2 text-xs rounded-lg border border-white/10 backdrop-blur-sm">
                  <Warehouse className="w-5 h-5 text-emerald-350" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm tracking-wide uppercase">
                    Register Spice Sourcing Co-Op
                  </h3>
                  <p className="text-[10px] text-emerald-200 mt-0.5 leading-none">Register Indonesian spice suppliers and farmers groups</p>
                </div>
              </div>
              <button
                onClick={() => setShowAddSupplierModal(false)}
                className="text-emerald-200 hover:text-white font-black text-xl cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={submitSupplier} className="p-6 space-y-4">
              
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                  Supplier Name / Co-Op Group
                </label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Koperasi Tani Banda Mutiara"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  value={newSupplierForm.name}
                  onChange={(e) => setNewSupplierForm({ ...newSupplierForm, name: e.target.value })}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                  Sourcing Region/Location
                </label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Banda Neira, Maluku"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  value={newSupplierForm.location}
                  onChange={(e) => setNewSupplierForm({ ...newSupplierForm, location: e.target.value })}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                  Estimated Supply Capacity (MT / Month)
                </label>
                <input
                  required
                  type="text"
                  placeholder="e.g. 15 MT / Month"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  value={newSupplierForm.supplyCapacity}
                  onChange={(e) => setNewSupplierForm({ ...newSupplierForm, supplyCapacity: e.target.value })}
                />
              </div>

              <div className="pt-4 flex gap-3 justify-end">
                <button
                  type="button"
                  onClick={() => setShowAddSupplierModal(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-500 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingSupplier}
                  className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md cursor-pointer flex items-center justify-center gap-1"
                >
                  {isSubmittingSupplier ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Register Co-Op"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------------
          MODAL: CONTAINER CALCULATOR
         --------------------------------------------------------- */}
      {showCalcModal && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in text-slate-800">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden border border-slate-150">
            
            <div className="p-5 bg-gradient-to-tr from-indigo-900 to-indigo-950 text-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="bg-indigo-500/20 p-2 rounded-lg border border-indigo-500/30">
                  <Scale className="w-5 h-5 text-indigo-300" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm tracking-wide uppercase">
                    Container Capacity Calculator
                  </h3>
                  <p className="text-[10px] text-indigo-200 mt-0.5 leading-none">Estimate stuffed volumes for standard 20ft and 40ft containers</p>
                </div>
              </div>
              <button
                onClick={() => setShowCalcModal(false)}
                className="text-indigo-200 hover:text-white font-black text-xl cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-6">
              
              {/* Left Column: Inputs (5 Cols) */}
              <div className="md:col-span-5 space-y-4">
                <span className="text-[10px] font-black tracking-widest uppercase text-slate-400 block border-b pb-1">
                  1. Cargo Dimensions
                </span>
                
                {/* Micro Presets Quick Selector */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 block">Package Presets:</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {[
                      { label: "Gunny 50kg", l: 60, w: 40, h: 25, wt: 50 },
                      { label: "Carton 25kg", l: 45, w: 35, h: 30, wt: 25 },
                      { label: "PP Bag 25kg", l: 55, w: 40, h: 18, wt: 25 },
                    ].map((preset) => (
                      <button
                        key={preset.label}
                        type="button"
                        onClick={() => setCalcForm({
                          bagLength: preset.l,
                          bagWidth: preset.w,
                          bagHeight: preset.h,
                          bagWeight: preset.wt,
                        })}
                        className="text-[9px] font-black bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded p-1 text-center text-slate-600 cursor-pointer"
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Input Fields */}
                <div className="space-y-3 pt-2">
                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-400 uppercase">Length (cm)</label>
                      <input
                        type="number"
                        min="1"
                        className="w-full px-2.5 py-2 border border-slate-200 rounded-lg text-xs"
                        value={calcForm.bagLength}
                        onChange={(e) => setCalcForm({ ...calcForm, bagLength: Math.max(1, parseInt(e.target.value) || 0) })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-400 uppercase">Width (cm)</label>
                      <input
                        type="number"
                        min="1"
                        className="w-full px-2.5 py-2 border border-slate-200 rounded-lg text-xs"
                        value={calcForm.bagWidth}
                        onChange={(e) => setCalcForm({ ...calcForm, bagWidth: Math.max(1, parseInt(e.target.value) || 0) })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-400 uppercase">Height (cm)</label>
                      <input
                        type="number"
                        min="1"
                        className="w-full px-2.5 py-2 border border-slate-200 rounded-lg text-xs"
                        value={calcForm.bagHeight}
                        onChange={(e) => setCalcForm({ ...calcForm, bagHeight: Math.max(1, parseInt(e.target.value) || 0) })}
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-400 uppercase block">Individual Net Weight (kg)</label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        min="1"
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                        value={calcForm.bagWeight}
                        onChange={(e) => setCalcForm({ ...calcForm, bagWeight: Math.max(1, parseInt(e.target.value) || 0) })}
                      />
                      <span className="bg-slate-100 text-slate-500 px-3 py-2 rounded-lg text-xs font-bold leading-none flex items-center select-none">
                        kg
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl space-y-1.5">
                  <span className="text-[9px] font-black uppercase tracking-widest block">Standard Capacity Constraints:</span>
                  <p className="text-[10px] leading-relaxed">
                    • <strong>20ft GP</strong>: Max pay volume 28.0 m³, Max safe cargo weight 21.5 MT<br />
                    • <strong>40ft GP</strong>: Max pay volume 58.0 m³, Max safe cargo weight 26.5 MT
                  </p>
                </div>

              </div>

              {/* Right Column: Calculated Outputs (7 Cols) */}
              <div className="md:col-span-7 bg-slate-50 p-5 rounded-2xl border border-slate-150 flex flex-col justify-between space-y-5">
                <div>
                  <span className="text-[10px] font-black tracking-widest uppercase text-slate-400 block border-b pb-1">
                    2. Ocean Capacity Outputs
                  </span>

                  {/* Calculations */}
                  {(() => {
                    const bagVolCm = calcForm.bagLength * calcForm.bagWidth * calcForm.bagHeight;
                    const bagVolM3 = bagVolCm / 1000000;
                    
                    // 20ft Limits
                    const volLimit28M3 = 28.0;
                    const bagsByVol20 = Math.floor(volLimit28M3 / bagVolM3);
                    const bagsByWt20 = Math.floor(21500 / calcForm.bagWeight);
                    const finalBags20 = Math.min(bagsByVol20, bagsByWt20);
                    const finalWt20MT = (finalBags20 * calcForm.bagWeight) / 1000;
                    const bneck20 = bagsByVol20 < bagsByWt20 ? "Volume Limited" : "Weight Limited";

                    // 40ft Limits
                    const volLimit58M3 = 58.0;
                    const bagsByVol40 = Math.floor(volLimit58M3 / bagVolM3);
                    const bagsByWt40 = Math.floor(26500 / calcForm.bagWeight);
                    const finalBags40 = Math.min(bagsByVol40, bagsByWt40);
                    const finalWt40MT = (finalBags40 * calcForm.bagWeight) / 1000;
                    const bneck40 = bagsByVol40 < bagsByWt40 ? "Volume Limited" : "Weight Limited";

                    return (
                      <div className="space-y-4 mt-3">
                        {/* Package Info Badge */}
                        <div className="flex justify-between text-xs font-semibold bg-white p-2.5 rounded-lg shadow-xs border border-slate-150">
                          <span className="text-slate-500">Vol. per pack Unit:</span>
                          <span className="text-slate-900 font-bold font-mono">
                            {bagVolM3.toFixed(3)} m³ ({bagVolCm.toLocaleString()} cm³)
                          </span>
                        </div>

                        {/* 20ft Output Card */}
                        <div className="bg-white p-3 rounded-xl border border-slate-150 shadow-xs relative overflow-hidden">
                          <div className="absolute right-3 top-3 bg-indigo-50 px-2 py-0.5 rounded text-[8px] font-black text-indigo-700 uppercase">
                            20FT Dry Container
                          </div>
                          <span className="text-[10px] font-black text-slate-400 block">Est. 20ft GP Capacity</span>
                          <div className="flex items-baseline gap-2 mt-1">
                            <span className="text-2xl font-black text-indigo-900 font-display">
                              {finalBags20.toLocaleString()}
                            </span>
                            <span className="text-[11px] font-bold text-slate-500">Unit Bags</span>
                          </div>
                          <div className="flex justify-between items-center text-[10px] text-slate-500 pt-2 border-t mt-2">
                            <span>Total Payload Wt: <strong>{finalWt20MT.toFixed(2)} MT</strong></span>
                            <span className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold ${bneck20 === "Volume Limited" ? "bg-cyan-50 text-cyan-700" : "bg-orange-50 text-orange-700"}`}>
                              {bneck20}
                            </span>
                          </div>
                        </div>

                        {/* 40ft Output Card */}
                        <div className="bg-white p-3 rounded-xl border border-slate-150 shadow-xs relative overflow-hidden">
                          <div className="absolute right-3 top-3 bg-purple-50 px-2 py-0.5 rounded text-[8px] font-black text-purple-700 uppercase">
                            40FT Dry Container
                          </div>
                          <span className="text-[10px] font-black text-slate-400 block">Est. 40ft GP Capacity</span>
                          <div className="flex items-baseline gap-2 mt-1">
                            <span className="text-2xl font-black text-purple-900 font-display">
                              {finalBags40.toLocaleString()}
                            </span>
                            <span className="text-[11px] font-bold text-slate-500">Unit Bags</span>
                          </div>
                          <div className="flex justify-between items-center text-[10px] text-slate-500 pt-2 border-t mt-2">
                            <span>Total Payload Wt: <strong>{finalWt40MT.toFixed(2)} MT</strong></span>
                            <span className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold ${bneck40 === "Volume Limited" ? "bg-cyan-50 text-cyan-700" : "bg-orange-50 text-orange-700"}`}>
                              {bneck40}
                            </span>
                          </div>
                        </div>

                      </div>
                    );
                  })()}
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={() => setShowCalcModal(false)}
                    className="w-full md:w-auto px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-black text-xs cursor-pointer text-center"
                  >
                    Close Assistant
                  </button>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* ---------------------------------------------------------
          MODAL: SPICE CURRENCY CONVERTER
         --------------------------------------------------------- */}
      {showConverterModal && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in text-slate-800">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-slate-150">
            
            <div className="p-5 bg-gradient-to-tr from-slate-900 to-indigo-950 text-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="bg-emerald-500/20 p-2 rounded-lg border border-emerald-500/30">
                  <Coins className="w-5 h-5 text-emerald-300 animate-bounce" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm tracking-wide uppercase">
                    Spice Currency Converter
                  </h3>
                  <p className="text-[10px] text-indigo-200 mt-0.5 leading-none">Standard Indonesian port exchange conversion helpers</p>
                </div>
              </div>
              <button
                onClick={() => setShowConverterModal(false)}
                className="text-indigo-200 hover:text-white font-black text-xl cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="p-6 space-y-4">
              
              {/* Spice Commodity Benchmarks Quick Selector */}
              <div className="space-y-1.5">
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 block">FOB Price Benchmarks:</span>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { label: "Nutmeg FOB", val: 8500, symbol: "USD" },
                    { label: "Cloves FOB", val: 9100, symbol: "USD" },
                    { label: "Mace FOB", val: 14200, symbol: "USD" },
                  ].map((bench) => (
                    <button
                      key={bench.label}
                      type="button"
                      onClick={() => setConvForm({
                        amount: bench.val.toString(),
                        fromCurrency: bench.symbol,
                        toCurrency: "IDR",
                      })}
                      className="text-[9px] font-bold bg-emerald-50/50 hover:bg-emerald-100 border border-emerald-150 rounded p-1.5 text-center text-emerald-800 cursor-pointer flex flex-col justify-center items-center"
                    >
                      <span className="font-extrabold block">{bench.label}</span>
                      <span className="text-[10px] font-mono mt-0.5 text-slate-500">${bench.val.toLocaleString()}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Amount input */}
              <div className="space-y-1.5 pt-2">
                <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                  Amount to Convert
                </label>
                <input
                  type="text"
                  placeholder="e.g. 1000"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  value={convForm.amount}
                  onChange={(e) => {
                    // Match numbers only
                    const cleaned = e.target.value.replace(/[^0-9.]/g, "");
                    setConvForm({ ...convForm, amount: cleaned });
                  }}
                />
              </div>

              {/* Conversion Selector Row */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                    From Currency
                  </label>
                  <select
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    value={convForm.fromCurrency}
                    onChange={(e) => setConvForm({ ...convForm, fromCurrency: e.target.value })}
                  >
                    <option value="USD">USD ($) - US Dollar</option>
                    <option value="IDR">IDR (Rp) - Indonesian Rupiah</option>
                    <option value="EUR">EUR (€) - Euro</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold tracking-widest uppercase text-slate-400">
                    To Currency
                  </label>
                  <select
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    value={convForm.toCurrency}
                    onChange={(e) => setConvForm({ ...convForm, toCurrency: e.target.value })}
                  >
                    <option value="USD">USD ($) - US Dollar</option>
                    <option value="IDR">IDR (Rp) - Indonesian Rupiah</option>
                    <option value="EUR">EUR (€) - Euro</option>
                  </select>
                </div>
              </div>

              {/* Live result conversion panel */}
              {(() => {
                const numericAmount = parseFloat(convForm.amount) || 0;
                
                // Exchange Rates (May 2026 realistic)
                // USD -> IDR: 16150
                // EUR -> IDR: 17400
                const RATES: Record<string, number> = {
                  USD_IDR: 16150,
                  EUR_IDR: 17400,
                  USD_EUR: 0.92,
                  IDR_USD: 1 / 16150,
                  IDR_EUR: 1 / 17400,
                  EUR_USD: 1 / 0.92,
                };

                let conversionRate = 1;
                if (convForm.fromCurrency !== convForm.toCurrency) {
                  const key = `${convForm.fromCurrency}_${convForm.toCurrency}`;
                  conversionRate = RATES[key] || 1;
                }
                const result = numericAmount * conversionRate;

                // Format symbol
                const formatOpts: Record<string, any> = {
                  USD: { style: "currency", currency: "USD", maximumFractionDigits: 2 },
                  EUR: { style: "currency", currency: "EUR", maximumFractionDigits: 2 },
                  IDR: { style: "currency", currency: "IDR", maximumFractionDigits: 0 },
                };

                const fInput = numericAmount.toLocaleString(undefined, { maximumFractionDigits: 2 });
                const fOutput = result.toLocaleString(undefined, formatOpts[convForm.toCurrency] || { maximumFractionDigits: 2 });

                return (
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-1">
                    <span className="text-[10px] font-black tracking-widest uppercase text-emerald-800">
                      Converted Trade value
                    </span>
                    <div className="text-xl font-black text-slate-900 font-display">
                      {fOutput}
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Exchange Value: {fInput} {convForm.fromCurrency} is equivalent to {fOutput} in {convForm.toCurrency}.
                    </p>
                    <p className="text-[8px] text-slate-400 uppercase tracking-wider pt-1">
                      * Realtime benchmark updates based on Central Bank IDR reference indexes
                    </p>
                  </div>
                );
              })()}

              <div className="pt-4 flex justify-end">
                <button
                  onClick={() => setShowConverterModal(false)}
                  className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-black text-xs cursor-pointer text-center w-full"
                >
                  Close Assistant
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* FOOTER PLATFORM METADATA */}
      <footer className="bg-white border-t border-slate-150 py-3 px-6 text-[10px] text-slate-400 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 z-10">
        <div className="flex items-center gap-2">
          <span>Exopilot Export Assistant Dashboard & Digital OS • Jakarta Gateway Liaison</span>
          <span className="text-slate-200">|</span>
          <span className="font-semibold text-indigo-600 uppercase">Indonesian Spice Co-operation</span>
        </div>
        <div>
          <span>Local Container Clock: 2026-05-23 (UTC)</span>
        </div>
      </footer>
    </div>
  );
}
